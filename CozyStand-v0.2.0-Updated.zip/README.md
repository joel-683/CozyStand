# CozyStand — Android Studio project

A native Kotlin + Jetpack Compose bedside clock starter designed for landscape tablets (including Xiaomi Pad 8) and responsive on phones.

## Included in this first build

- Full-screen landscape-friendly clock with live time and date
- Four clock faces: Digital, Flip-style, Minimal and Analog-style
- 12/24-hour option and seconds toggle
- Six built-in colour moods: Oat milk, Walnut, Moss, Dusk, Terracotta and Midnight
- Select a photo from the device using Android's document picker
- Wallpaper palette extraction to adapt accent and foreground text colours
- Main-screen media controls plus a dedicated music screen
- Android active media-session integration for compatible media apps
- Persistent theme, clock and wallpaper preferences
- Keep-screen-on behaviour for bedside use

## Build with Android Studio

1. Install Android Studio (current stable) and its Android SDK Platform 35, Build Tools and Platform Tools.
2. Open this `CozyStand` folder in Android Studio. If Android Studio asks for a Gradle installation, install Gradle 8.11.1 or use a local Gradle 8.11.1 installation.
3. In the project folder, run `gradle wrapper --gradle-version 8.11.1` once (or run `./build-debug.sh` after installing Gradle).
4. Allow Gradle sync to download the Android Gradle Plugin and dependencies.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The debug APK will be created at `app/build/outputs/apk/debug/app-debug.apk`.
7. Install it on the tablet with `adb install -r app/build/outputs/apk/debug/app-debug.apk`, or copy the APK to the device and open it.

Project settings: `compileSdk 35`, `targetSdk 35`, `minSdk 26`, Java/Kotlin target 17. Gradle plugin 8.10.1 and Gradle 8.11.1 are configured in the project files.

## Enable music controls

Android protects active media sessions. In CozyStand, open **Themes → Open media access settings**, then enable **CozyStand media access** under Android's Notification access settings. Start playback in YouTube Music, Spotify, VLC or another media app and return to CozyStand. The app reads the active Android media session; it does not sign in to those services or bypass their background-playback rules. Some apps/devices expose limited metadata or controls, and some sessions may not be available until playback starts.

## Notes / current limitations

- This workspace does not contain the Android SDK, Gradle executable, Gradle wrapper JAR, or network access to download them. Therefore an APK could not be compiled or device-tested here. Open the project in Android Studio to build the APK.
- The first version uses a static analog-style clock face and a flip-inspired digital face; animated flip transitions and fully accurate analog hands are planned polish items.
- Wallpaper-derived colours use AndroidX Palette's dominant/vibrant swatches. The user can always switch to a preset mood.
- Media session access requires explicit user consent through Android Notification access. YouTube/YouTube Music availability depends on the media session exposed by the installed app and Android version.
- No analytics, account, cloud sync, or network permission is included.

## Package

`com.cozystand.app`


## Version 0.2.0 changes
- Enlarged the main clock for tablet landscape use.
- Removed the Photo shortcut from the home controls; wallpaper selection remains available in Themes/settings.
- Added Android Back gesture handling so the expanded music screen and settings sheet return to the main clock screen.
- Improved media-session selection to prefer the actively playing app, refresh on app resume, and explain the required Android Notification access permission.

### Media controls setup
On the tablet, open CozyStand → Themes → Media access → Open media access settings, then enable CozyStand under Notification access. Start playback in YouTube, YouTube Music, Spotify, VLC, or another app that exposes an Android media session, then return to CozyStand. Some YouTube playback modes may not expose a controllable media session; CozyStand cannot bypass YouTube's background-playback restrictions.
