# CozyStand 0.5.1 — Clean Clock Layout

This source project keeps the oversized clock and glass-style media card as the focus and removes the bottom app shortcut dock / bottom control bar from the home screen.

- Media card retains play/pause, previous/next and expand controls.
- Settings remain available from the top-right gear on wide tablet layout.
- Android's own system gesture/navigation indicator is not part of the app and is unaffected.
- Media control requires Android Notification access and an active media session from the playback app.

Build with the repository's existing GitHub Actions workflow.
