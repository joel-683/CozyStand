# CozyStand v0.6.0 — Standby UI correction

## Changes
- Removed the CozyStand / Standby Display header bar. Only the settings gear remains at the top.
- Enlarged the digital clock responsively for landscape tablets.
- Removed the separate full-screen music player page and its expand action.
- Kept playback controls directly on the standby screen.
- Rebuilt the media card with a larger square artwork area and `ContentScale.Fit` so artwork is not stretched or aggressively cropped.
- Made the settings sheet vertically scrollable and capped its height so the Media access section remains reachable.

## Build
Use the existing GitHub Actions workflow from your repository. Keep `.github/workflows` when replacing the app source. This ZIP contains Android source code, not a precompiled APK.

## Notes
The playback progress display is still a visual indicator; precise seek/progress timing requires reading and displaying the active MediaSession playback position.
