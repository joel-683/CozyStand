# Claude task: redesign CozyStand clock and media player UI

You are working on an existing Android app called **CozyStand**, written in Kotlin with Jetpack Compose. Your task is to make a real implementation change in the supplied project, not produce a mockup or general advice.

## Main goal
Redesign the **main standby screen** to feel polished, calm and premium, taking inspiration from Google's modern Material You / Pixel design language. Do not copy Google's branding or proprietary assets. The app is primarily used on a Xiaomi Pad 8 in landscape, but must remain usable on phones and portrait layouts.

## Highest-priority requirements

### 1. Make the clock absolutely massive
- The time must be the dominant element on the screen, much larger than in the current screenshots.
- Use responsive sizing based on available width and height, not a fixed size that clips on different devices.
- On the landscape tablet, aim for a very large display-clock treatment that occupies a substantial portion of the screen while leaving room for the media card.
- Keep the date smaller and visually secondary, above or near the time.
- Support both 12-hour and 24-hour formats if the app already has that setting.
- Prevent clipping, wrapping, overlap, and layout jumps when the time changes or AM/PM is shown.
- Use proper baseline alignment and optical spacing. The clock should look intentionally designed, not merely enlarged text.

### 2. Add clock font/style customization
Add a setting for changing the clock's typeface/style. It must work, not be a decorative or inert selector.
- Provide a small curated set of visually distinct styles, for example: Clean / Google-like sans, Rounded, Geometric, Serif, Digital.
- Use bundled or dependable system fonts/resources; do not rely on remote downloads.
- Show a live preview or immediately apply the selected style to the main clock.
- Persist the user's selection using the project's existing persistence approach (DataStore/preferences if already present). Do not introduce a second conflicting settings store.
- Ensure all styles remain legible at very large sizes and support numerals consistently.
- If the app already has a clock-style setting, extend/fix it rather than creating a duplicate.

### 3. Redesign the media player card
The current player looks poor and the artwork thumbnails are stretched/cropped badly. Replace it with one elegant, compact-but-generous media card on the main screen.
- Use a modern Material You-inspired surface: balanced rounded corners, subtle tonal contrast, restrained translucency only if it remains readable, and good spacing.
- Album artwork should have a consistent square aspect ratio, use `ContentScale.Crop` (or an appropriate fit strategy) intentionally, clip to rounded corners, and never stretch. Keep the artwork visually crisp and bounded.
- Handle missing artwork gracefully with a designed fallback (app/music glyph and tonal background), not a broken image or empty black box.
- Track title and artist must have a clear hierarchy, support long text with ellipsis, and never collide with controls.
- Include previous, play/pause, and next controls with accessible touch targets and clear pressed/disabled states.
- Include a progress indicator/slider only if the current media-session implementation supplies reliable duration and position. Do not invent progress or show misleading values.
- Make the card adapt cleanly to landscape tablet and narrow phone layouts.
- If no media session is active, show a tasteful idle state or hide the card according to the existing app behavior; do not show fake track metadata.
- Preserve existing Android MediaSession / notification-listener integration and supported playback apps. Do not replace real playback actions with decorative buttons.

## Keep / remove
- Keep the settings entry point (gear) on the main screen.
- Remove the CozyStand / “Standby Display” branding header from the main screen.
- Do not add a bottom app dock, bottom toolbar, or app shortcut bar.
- Do not add a separate dedicated full-screen playing page. Playback belongs on the main standby screen.
- The main screen should focus on the giant clock and the redesigned media card.
- Settings must remain reachable and all settings content must be visible/scrollable; fix any clipped media/permission settings sections.

## Design direction
- Google-inspired, clean, warm, polished Material You / Pixel aesthetic.
- Strong typographic hierarchy, generous spacing, restrained shapes and surfaces, coherent tonal palette.
- Prioritize the clock over everything else.
- Avoid excessive gradients, glowing effects, clutter, unnecessary labels, tiny controls, and generic dashboard styling.
- Keep the wallpaper/background approach already supported by the project if practical; ensure foreground contrast is always sufficient.

## Supplied references
- `reference-screenshots/current-main-screen.jpg`: current app main screen; use it to identify existing problems.
- `reference-screenshots/current-settings-screen.jpg`: current settings screen; the media section is partially cut off and must be fixed.
- `design-reference/desired-visual-reference.png`: earlier visual direction for the large clock and integrated media player. Use it as inspiration, but apply the more Google-like design direction specified above.

## Engineering requirements
1. First inspect the entire project and identify the actual Compose screen(s), state, navigation, settings persistence, media session service/listener, and resources.
2. Keep the existing package name, app ID, manifest declarations, permissions, Gradle setup, and working media integration unless a change is strictly necessary.
3. Do not rewrite the whole app unnecessarily. Make focused, maintainable changes.
4. Use correct Compose scopes. Avoid implicit `maxWidth` / `maxHeight` receiver mistakes; capture constraints explicitly with `BoxWithConstraints` or use `LocalConfiguration` / measured constraints appropriately.
5. Make layouts responsive for tablet landscape, tablet portrait, and phone sizes. Avoid hard-coded dimensions that cause clipping.
6. Ensure settings selectors are wired to state and persisted. Every visible control must work.
7. Preserve accessibility: content descriptions, adequate contrast, touch targets (roughly 48dp), and scalable text where appropriate.
8. Check imports and avoid duplicate composables, unresolved symbols, and deprecated APIs where practical.
9. Run a Gradle debug build if the environment allows. At minimum, inspect the code carefully for compile errors. Do not claim a successful build unless you actually ran it and it succeeded.
10. Do not remove existing functionality unrelated to this requested UI redesign.

## Deliverables
- Return the **complete corrected Android Studio project** as a ZIP, not just snippets or one Kotlin file.
- Include a concise change summary and list any build/test results honestly.
- If a build fails, include the exact remaining errors and fix them before calling the work complete.
- Keep the project easy to open and build in Android Studio.

## Suggested acceptance checklist
- [ ] Clock is dramatically larger on Xiaomi Pad 8 landscape and is still fully visible.
- [ ] User can change clock font/style in Settings.
- [ ] Clock style selection updates the main screen and persists after app restart.
- [ ] Media card looks polished and balanced.
- [ ] Album art is never stretched; missing artwork has a proper fallback.
- [ ] Track title/artist do not overlap artwork or controls.
- [ ] Previous/play-pause/next control real playback sessions.
- [ ] No branding header, no bottom dock, no separate playing page.
- [ ] Settings content, including media access, is fully visible and scrollable.
- [ ] Project compiles successfully, or remaining errors are explicitly reported.
