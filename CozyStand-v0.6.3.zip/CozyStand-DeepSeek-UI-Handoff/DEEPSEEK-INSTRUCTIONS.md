# CozyStand — UI repair and redesign handoff

You are editing an existing native Android application written in Kotlin and Jetpack Compose. The complete Android Studio project is in the `project/` folder. Do not replace it with a web app, Flutter app, mockup, or static image.

## Goal
Use the updated v0.6.3 project snapshot as the baseline. Make the real running Android UI closely match `design-reference/desired-visual-reference.png`, while correcting the problems shown in `reference-screenshots/`.

## User's exact design requirements
1. This is a landscape-first bedside/standby clock for a tablet, with phone support where practical.
2. The clock must be extremely large, visually dominant, centred, and responsive to available screen dimensions. Put a small date above it.
3. Remove the top branding/header text such as “CozyStand” and “Standby Display”. Keep only a small settings gear in the top-right corner.
4. Remove the bottom app dock/bar completely. Do not add a bottom toolbar, app shortcuts, or bottom navigation.
5. Remove the separate/dedicated full-screen playing page. Playback controls must remain on the main standby screen.
6. Redesign the media player as an attractive, premium translucent/glass-style card below the clock. It should have balanced spacing and clear hierarchy.
7. Album artwork must preserve its aspect ratio, be contained/cropped intentionally (never stretched), have consistent rounded corners, and use a sensible fixed/aspect-ratio-aware size. Avoid oversized or tiny thumbnails.
8. Show track title and artist with sensible ellipsizing, plus previous, play/pause, next and a playback progress indicator/slider when available.
9. The media card must adapt to different landscape tablet sizes without clipping or overflowing. Settings content must be scrollable; the media/notification access section must not be cut off.
10. Keep the existing app functionality and permissions unless a change is necessary. Do not silently remove media-session integration, settings, theme/wallpaper options, or clock preferences.
11. The launcher icon should be a polished custom CozyStand icon, not the default Android icon.

## Current known build errors in the supplied project
The previous GitHub Actions builds reported Kotlin Compose errors in `MainActivity.kt`:
- `Unresolved reference 'isWide'` around line 187.
- `maxHeight: Dp cannot be called in this context with an implicit receiver` around line 220.
A previous revision also had an implicit receiver `maxWidth` error. Inspect the current source and fix the root cause cleanly. Do not merely suppress compiler errors or guess line numbers; line numbers may have shifted.

## Implementation instructions
- First inspect the entire project, especially `app/src/main/java/com/cozystand/app/MainActivity.kt`, manifest, Gradle files, and resources.
- Make the changes in the actual Kotlin/Jetpack Compose implementation. Do not just provide a design description or image.
- Use explicit Compose scopes and `BoxWithConstraints` values correctly. Avoid relying on implicit `maxWidth`/`maxHeight` receivers inside nested composables.
- Use responsive layouts based on available width/height and orientation, not hard-coded dimensions that only fit one emulator.
- Use `ContentScale.Crop` only where intentional; for album art prefer a square aspect ratio and `ContentScale.Crop` within a bounded square, or `Fit` if showing the entire artwork is more important. Never distort the source image.
- Ensure the settings screen uses a vertically scrollable container and respects system insets.
- Preserve accessibility: readable contrast, adequate touch targets, content descriptions, and sensible text scaling.
- Check that all composables and imports compile. If you can run Gradle, run `./gradlew assembleDebug` and fix all Kotlin/resource/manifest errors before returning.
- Do not claim the APK was built or tested unless you actually ran the build and report its result.

## Expected output
Return the complete corrected Android Studio project, preferably as a ZIP preserving the Gradle project structure. Also provide a concise list of changed files and a truthful build status. Do not return only snippets: I need to replace the project and build an APK.
