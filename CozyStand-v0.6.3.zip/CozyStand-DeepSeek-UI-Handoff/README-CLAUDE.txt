COZYSTAND — ANDROID UI REDESIGN HANDOFF

1. Upload this entire ZIP to Claude (or extract it and upload the project plus reference images).
2. Open CLAUDE-INSTRUCTIONS.md and ask Claude to follow it.
3. Ask Claude to return the complete corrected Android Studio project as a ZIP.

Important: The project included is the latest supplied source snapshot, updated to v0.6.3. It has not been independently built or runtime-tested in this handoff.

Contents:
- project/: complete Android project source
- reference-screenshots/: screenshots of the current app
- design-reference/: desired visual direction
- CLAUDE-INSTRUCTIONS.md: detailed implementation brief
