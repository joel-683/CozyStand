Upload the project ZIP or its extracted contents to DeepSeek together with DEEPSEEK-INSTRUCTIONS.md and the reference images.

Important:
- `project/` is the current CozyStand Android source project (v0.6.3).
- `reference-screenshots/` shows the actual app screens and problems.
- `design-reference/` shows the desired visual direction.
- Ask DeepSeek to return a complete corrected Android Studio project ZIP, not just code snippets.
- Ask it to report whether it actually ran a successful Gradle build.
