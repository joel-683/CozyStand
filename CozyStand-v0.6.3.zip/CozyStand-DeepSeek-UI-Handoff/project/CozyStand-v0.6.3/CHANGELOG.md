# Changelog

## 0.6.3
- Added persistent clock typeface, weight, and colour preferences with a live preview.
- Made the main digital clock scale against both landscape width and height.
- Connected media progress and seeking to MediaSession playback position and duration.
- Updated Android app version metadata.
