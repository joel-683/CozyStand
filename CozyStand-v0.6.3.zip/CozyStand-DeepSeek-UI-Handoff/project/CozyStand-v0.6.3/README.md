# CozyStand v0.6.3 — Standby display refinement

## Changes in this snapshot
- Kept the standby screen free of branding headers, bottom docks, and a separate full-screen media page.
- Increased the landscape clock's responsive size while constraining it against both available width and height.
- Added persistent clock typeface choices using distinct Android system font families: sans-serif (Google Sans-inspired), serif, monospace/digital, and cursive.
- Added persistent clock weight choices and a live type preview in Settings.
- Added persistent clock colour swatches with a theme-colour reset.
- Kept the existing theme and wallpaper selection, including wallpaper-derived accent colours.
- Replaced the fabricated media progress fill with the active MediaSession's reported position and duration; seeking uses `MediaController.TransportControls.seekTo` when the session provides a duration.
- Kept album art in a bounded square container using `ContentScale.Fit`, preserving the original image ratio.
- Kept Settings vertically scrollable and retained Notification Listener access for compatible media apps.
- Updated Android `versionCode` to 6 and `versionName` to `0.6.3`.

## Build status
This source snapshot has **not** been built in the current environment. The supplied archive does not contain `gradlew` or `gradle-wrapper.jar`, and this environment has no installed Gradle distribution or Android SDK. The Android project files were inspected and the Kotlin source passed a parser-level syntax check, but that is not a substitute for an Android Gradle build.

Open the project in Android Studio and allow Gradle sync. If you are replacing files in an existing GitHub repository, keep that repository's `.github/workflows` directory and its Gradle wrapper files.

## Known limitations
- The typeface choices use Android's built-in system families; no external font files or Google Sans font binary are bundled.
- Media metadata, playback state, duration, and seeking depend on the source app publishing a compatible Android MediaSession. Some apps may not expose all fields or transport actions.
- The archive supplied for this update did not include a `.github/workflows` directory, so no workflow file could be carried forward inside this ZIP.
