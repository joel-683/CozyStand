# CozyStand v0.7.0 — standby redesign

A landscape-first bedside clock: a very large clock, the date above it, and one integrated media card.
Kotlin + Jetpack Compose, package/app ID `com.cozystand.app` (unchanged).

## Build status (read this first)
**This project has NOT been compiled or run.** It was produced in a sandbox with no access to Gradle, the
Android SDK or Google Maven, so `./gradlew assembleDebug` could not be executed. What was verified:
- every Kotlin file passes the Kotlin 2.1.21 compiler's *parser* (no syntax errors);
- all XML resources are well-formed;
- the layout/fit maths was simulated with the real bundled fonts.
Type-checking against Compose/Android was **not** possible. Please build once and report any compiler error.

## Build
```
./gradlew assembleDebug        # APK: app/build/outputs/apk/debug/app-debug.apk
```
Needs JDK 17+, Android SDK 35. Or open the folder in Android Studio (Ladybug or newer) and press Run.
`gradlew` / `gradle-wrapper.jar` are the official Gradle 8.11.1 wrapper files (the previous zip had none).
Do not replace your repo's `.github/workflows`.

## What changed
- **Main screen**: no header, no "Standby Display", no dock, no separate player page. Only the gear (top right),
  date, clock and media card. Clock size is measured from real text layout and fitted to the available
  space, so it cannot clip and does not change size as the time changes.
- **Clock customisation** (Settings > Display): six genuinely different bundled fonts, weight, style
  (Digital, Minimal, Flip, Analog — the analog hands now really move), spacing, colour, 12/24-hour, seconds.
  A live preview is pinned beside the list on tablets and above it on phones. All choices persist.
- **Media card**: square rounded artwork (`ContentScale.Crop`, never stretched; black letterbox bars baked
  into video thumbnails are trimmed first), title/artist with ellipsis, real progress bar and times (only when
  the player reports position and duration), previous / play-pause / next wired to the real MediaSession.
  Designed fallback for missing artwork, and idle / access-needed states.
- **Media integration**: session, metadata and playback *callbacks* instead of 1.2 s polling; position is
  extrapolated using the player's own speed. Notification-listener service and permission flow unchanged.
- **Settings**: full-page screen (Display / Media / General) that scrolls and respects insets, replacing the
  clipped bottom sheet.
- **Fixes**: removed the `isWide` / implicit `maxWidth`/`maxHeight` receiver errors (the layout was rewritten);
  wallpaper is now decoded off the main thread and downsized (it used to decode full size on the UI thread,
  and produced hardware bitmaps Palette cannot read); themes now actually colour the background (a hard-coded
  purple gradient used to cover them); launcher icon rescaled into the adaptive-icon safe zone, gradient
  background and Android 13 themed (monochrome) layer added.

## Files
`MainActivity.kt` activity + root · `StandbyScreen.kt` main screen · `ClockViews.kt` clock ·
`MediaCard.kt` player UI · `MediaState.kt` MediaSession monitor · `SettingsScreen.kt` · `CozyPrefs.kt` settings
state · `CozyTheme.kt` themes/palette · `ClockFonts.kt` fonts · `WallpaperLoader.kt` · `Previews.kt`.
Unchanged: `MediaSessionNotificationListener.kt`, Gradle config (only version bumped to 0.7.0 / code 7).

## Dependencies
None added. `datastore-preferences`, `androidx.media` and `material-icons-extended` were already declared.
Settings stay in the existing SharedPreferences file ("cozystand", original keys kept).

## Known limitations
- Phones in portrait get a width-limited single-line clock (no stacked hours/minutes layout).
- Artwork supplied only as a URL (no bitmap) is not loaded; the fallback tile is shown.
- The progress bar is display-only (no seeking).
- The card is a translucent tinted surface, not a true blur of the content behind it.
- Fonts: Google Sans is proprietary, so "Soft sans" uses Figtree, an open Google Sans–like face.
  Licences: see `THIRD_PARTY_FONTS.md` and `licenses/`.
