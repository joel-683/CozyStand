# Bundled fonts (SIL Open Font License 1.1)

Static instances in `app/src/main/res/font/` were generated from the variable originals (one file per weight,
subset to Latin). Licence texts are in `licenses/`.

| Option | Typeface | Source |
|---|---|---|
| Soft sans | Figtree | github.com/erikdkennedy/figtree |
| Geometric | Outfit | github.com/Outfitio/Outfit-Fonts |
| Clean | Inter | github.com/rsms/inter |
| Elegant serif | Fraunces | github.com/undercasetype/Fraunces |
| Rounded | Fredoka | github.com/hafontia/Fredoka-One |
| Digital | DSEG7 Classic (unmodified) | github.com/keshikan/DSEG |
