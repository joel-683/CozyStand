package com.cozystand.app

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import kotlin.math.abs

/** Weights the settings UI can offer, in display order. A font only offers the ones it actually ships. */
internal val ClockWeightLabels: List<Pair<Int, String>> = listOf(
    300 to "Light",
    400 to "Regular",
    500 to "Medium",
    600 to "SemiBold",
    700 to "Bold"
)

private fun familyOf(vararg files: Pair<Int, Int>): FontFamily =
    FontFamily(files.map { (weight, resId) -> Font(resId, FontWeight(weight)) })

// Every weight below is a real, separate static font file in res/font (generated from the open-source
// variable originals). Nothing here is a synthetic bold or a renamed copy of another typeface.
private val FigtreeFamily = familyOf(
    300 to R.font.clock_figtree_w300, 400 to R.font.clock_figtree_w400, 500 to R.font.clock_figtree_w500,
    600 to R.font.clock_figtree_w600, 700 to R.font.clock_figtree_w700
)
private val OutfitFamily = familyOf(
    300 to R.font.clock_outfit_w300, 400 to R.font.clock_outfit_w400, 500 to R.font.clock_outfit_w500,
    600 to R.font.clock_outfit_w600, 700 to R.font.clock_outfit_w700
)
private val InterFamily = familyOf(
    300 to R.font.clock_inter_w300, 400 to R.font.clock_inter_w400, 500 to R.font.clock_inter_w500,
    600 to R.font.clock_inter_w600, 700 to R.font.clock_inter_w700
)
private val FrauncesFamily = familyOf(
    300 to R.font.clock_fraunces_w300, 400 to R.font.clock_fraunces_w400, 500 to R.font.clock_fraunces_w500,
    600 to R.font.clock_fraunces_w600, 700 to R.font.clock_fraunces_w700
)
private val FredokaFamily = familyOf(
    300 to R.font.clock_fredoka_w300, 400 to R.font.clock_fredoka_w400, 500 to R.font.clock_fredoka_w500,
    600 to R.font.clock_fredoka_w600, 700 to R.font.clock_fredoka_w700
)
private val Dseg7Family = familyOf(
    300 to R.font.clock_dseg7_w300, 400 to R.font.clock_dseg7_w400, 700 to R.font.clock_dseg7_w700
)

/** The app-wide UI typeface (settings, media card). Same family as the default clock font. */
internal val UiFontFamily: FontFamily = FigtreeFamily

/**
 * @param digitInkEm height of the tallest numeral as a fraction of the font size, measured from the
 *   font files. The clock uses it to size its layout box around the real glyphs instead of the font's
 *   (much taller) line box, so spacing to the date above is exact.
 * @param labelFamily font for the date and AM/PM when the clock font cannot render letters (7-segment).
 */
internal enum class ClockFont(
    val key: String,
    val label: String,
    val blurb: String,
    val family: FontFamily,
    val weights: List<Int>,
    val digitInkEm: Float,
    val labelFamily: FontFamily = family
) {
    SOFT_SANS("soft", "Soft sans", "Friendly and Google Sans–like", FigtreeFamily, listOf(300, 400, 500, 600, 700), 0.713f),
    GEOMETRIC("geometric", "Geometric", "Modern, perfectly round", OutfitFamily, listOf(300, 400, 500, 600, 700), 0.718f),
    CLEAN("clean", "Clean", "Neutral and minimal", InterFamily, listOf(300, 400, 500, 600, 700), 0.739f),
    SERIF("serif", "Elegant serif", "High-contrast display serif", FrauncesFamily, listOf(300, 400, 500, 600, 700), 0.731f),
    ROUNDED("rounded", "Rounded", "Playful, soft corners", FredokaFamily, listOf(300, 400, 500, 600, 700), 0.705f),
    DIGITAL("digital", "Digital", "Seven-segment display", Dseg7Family, listOf(300, 400, 700), 1.0f, labelFamily = FigtreeFamily);

    /** Closest weight this font really has, so a saved preference never requests a missing file. */
    fun nearestWeight(requested: Int): Int = weights.minByOrNull { abs(it - requested) } ?: 400

    companion object {
        fun fromKey(key: String?): ClockFont = entries.firstOrNull { it.key == key } ?: SOFT_SANS
    }
}

/** Keys match the strings the previous version stored under "clock", so existing choices survive. */
internal enum class ClockStyle(val key: String, val label: String, val blurb: String) {
    DIGITAL("Digital", "Digital", "Hours, minutes and extras"),
    MINIMAL("Minimal", "Minimal", "Hours and minutes only"),
    FLIP("Flip", "Flip", "Split-flap cards"),
    ANALOG("Analog", "Analog", "Hands and ticks");

    companion object {
        fun fromKey(key: String?): ClockStyle = entries.firstOrNull { it.key == key } ?: DIGITAL
    }
}

internal enum class ClockSpacing(val key: String, val label: String, val em: Float) {
    TIGHT("tight", "Tight", -0.045f),
    NORMAL("normal", "Normal", -0.015f),
    WIDE("wide", "Wide", 0.03f);

    companion object {
        fun fromKey(key: String?): ClockSpacing = entries.firstOrNull { it.key == key } ?: NORMAL
    }
}

/** A null [color] means "follow the theme" (Auto) or the accent colour, resolved by the caller. */
internal enum class ClockColorOption(val key: String, val label: String, val color: Color?) {
    AUTO("auto", "Auto", null),
    ACCENT("accent", "Accent", null),
    WHITE("white", "White", Color(0xFFFFFFFF)),
    CREAM("cream", "Cream", Color(0xFFFFF1D6)),
    PEACH("peach", "Peach", Color(0xFFFFC9B0)),
    ROSE("rose", "Rose", Color(0xFFFFC2D9)),
    LAVENDER("lavender", "Lavender", Color(0xFFDCCBFF)),
    SKY("sky", "Sky", Color(0xFFBFE3FF)),
    MINT("mint", "Mint", Color(0xFFBDF0D2));

    companion object {
        fun fromKey(key: String?): ClockColorOption = entries.firstOrNull { it.key == key } ?: AUTO
    }
}
