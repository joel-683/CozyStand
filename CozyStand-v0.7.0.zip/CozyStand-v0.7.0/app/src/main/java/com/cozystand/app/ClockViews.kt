package com.cozystand.app

import android.text.format.DateFormat as AndroidDateFormat
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.AlignmentLine
import androidx.compose.ui.layout.FirstBaseline
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Everything the clock needs to draw. Changing any field cross-fades to the new look. */
@Immutable
internal data class ClockConfig(
    val font: ClockFont,
    val weight: Int,
    val style: ClockStyle,
    val spacing: ClockSpacing,
    val use24h: Boolean,
    val showSeconds: Boolean,
    val color: Color,
    val accent: Color,
    val cardTint: Color
)

internal data class TimeParts(val hours: String, val minutes: String, val seconds: String, val period: String?)

internal fun timeParts(now: LocalDateTime, use24h: Boolean, padHours: Boolean = use24h): TimeParts {
    val h = if (use24h) now.hour else (now.hour % 12).let { if (it == 0) 12 else it }
    val hours = h.toString().let { if (padHours) it.padStart(2, '0') else it }
    return TimeParts(
        hours = hours,
        minutes = now.minute.toString().padStart(2, '0'),
        seconds = now.second.toString().padStart(2, '0'),
        period = if (use24h) null else if (now.hour < 12) "AM" else "PM"
    )
}

/** Wall-clock time that ticks on each second boundary (so the display never lags by up to a second). */
@Composable
internal fun rememberNow(): State<LocalDateTime> = produceState(initialValue = LocalDateTime.now()) {
    while (true) {
        value = LocalDateTime.now()
        delay(1000L - System.currentTimeMillis() % 1000L + 5L)
    }
}

/**
 * Date above a clock that fills whatever space it is given. The clock is sized from measured text so it
 * can never clip, and the whole group is centred in the region.
 */
@Composable
internal fun ClockSection(config: ClockConfig, modifier: Modifier = Modifier) {
    val now by rememberNow()
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        // Captured here in the BoxWithConstraints scope; nested composables receive plain values.
        val regionHeight = maxHeight
        val dateSp = (regionHeight.value * 0.06f).coerceIn(15f, 30f)
        val gap = (dateSp * 0.6f).dp
        val clockMaxHeight = (regionHeight - (dateSp * 1.5f).dp - gap).coerceAtLeast(48.dp)
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            DateLabel(now, config, dateSp)
            Spacer(Modifier.height(gap))
            ClockFace(config, now, Modifier.fillMaxWidth().heightIn(max = clockMaxHeight))
        }
    }
}

private fun dateFormatter(locale: Locale): DateTimeFormatter = runCatching {
    DateTimeFormatter.ofPattern(AndroidDateFormat.getBestDateTimePattern(locale, "EEEMMMd"), locale)
}.getOrElse { DateTimeFormatter.ofPattern("EEE, d MMM", locale) }

@Composable
private fun DateLabel(now: LocalDateTime, c: ClockConfig, sizeSp: Float) {
    val locale = Locale.getDefault()
    val formatter = remember(locale) { dateFormatter(locale) }
    Text(
        text = now.format(formatter),
        color = c.color.copy(alpha = 0.85f),
        style = TextStyle(
            fontFamily = c.font.labelFamily,
            fontWeight = FontWeight(c.font.nearestWeight(500)),
            fontSize = sizeSp.sp,
            letterSpacing = 0.4.sp
        ),
        maxLines = 1
    )
}

@Composable
internal fun ClockFace(config: ClockConfig, now: LocalDateTime, modifier: Modifier = Modifier) {
    val parts = timeParts(now, config.use24h)
    val spoken = parts.hours + ":" + parts.minutes + (parts.period?.let { " $it" } ?: "")
    Crossfade(
        targetState = config,
        animationSpec = tween(380),
        modifier = modifier.clearAndSetSemantics { contentDescription = spoken },
        label = "clockStyle"
    ) { c ->
        when (c.style) {
            ClockStyle.ANALOG -> AnalogFace(c, now)
            ClockStyle.FLIP -> FlipFace(c, now)
            ClockStyle.MINIMAL -> DigitalFace(c, now, showExtras = false)
            ClockStyle.DIGITAL -> DigitalFace(c, now, showExtras = true)
        }
    }
}

private fun clockTextStyle(c: ClockConfig, size: TextUnit): TextStyle = TextStyle(
    color = c.color,
    fontFamily = c.font.family,
    fontWeight = FontWeight(c.weight),
    fontSize = size,
    letterSpacing = c.spacing.em.em,
    fontFeatureSettings = "tnum" // equal-width numerals where the font has them, so digits do not jitter
)

private fun buildClockText(
    c: ClockConfig,
    hours: String,
    minutes: String,
    seconds: String?,
    period: String?,
    sizeSp: Float
): AnnotatedString = buildAnnotatedString {
    append(hours)
    append(":")
    append(minutes)
    // Seconds and AM/PM share the digits' baseline, so they sit on one line without moving the big numerals.
    if (seconds != null) {
        withStyle(SpanStyle(fontSize = (sizeSp * 0.30f).sp)) {
            append(":")
            append(seconds)
        }
    }
    if (period != null) {
        withStyle(SpanStyle(fontSize = (sizeSp * 0.5f).sp)) { append(" ") }
        withStyle(
            SpanStyle(
                fontSize = (sizeSp * 0.17f).sp,
                fontFamily = c.font.labelFamily,
                color = c.color.copy(alpha = 0.78f)
            )
        ) { append(period) }
    }
}

/**
 * Text whose layout box hugs the numerals (baseline to digit top) instead of the font's much taller line
 * box. That makes vertical spacing exact and centring optically correct for every font.
 */
@Composable
private fun InkText(text: AnnotatedString, style: TextStyle, inkEm: Float, modifier: Modifier = Modifier) {
    val density = LocalDensity.current
    val inkPx = (with(density) { style.fontSize.toPx() } * inkEm).roundToInt()
    Text(
        text = text,
        style = style,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Visible,
        modifier = modifier.layout { measurable, _ ->
            val placeable = measurable.measure(Constraints())
            val rawBaseline = placeable[FirstBaseline]
            val baseline = if (rawBaseline == AlignmentLine.Unspecified) (placeable.height * 0.8f).roundToInt() else rawBaseline
            layout(placeable.width, inkPx) { placeable.placeRelative(0, inkPx - baseline) }
        }
    )
}

// ---------------------------------------------------------------------------------------------------------
// Digital / Minimal
// ---------------------------------------------------------------------------------------------------------

@Composable
private fun DigitalFace(c: ClockConfig, now: LocalDateTime, showExtras: Boolean) {
    val measurer = rememberTextMeasurer()
    val density = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val availW = constraints.maxWidth.toFloat()
        val availH = constraints.maxHeight.toFloat()
        val seconds = showExtras && c.showSeconds
        val period = showExtras && !c.use24h
        val sizeSp = remember(c.font, c.weight, c.spacing, seconds, period, availW, availH, density) {
            fitDigitalSp(measurer, density, c, seconds, period, availW, availH)
        }
        val parts = timeParts(now, c.use24h)
        InkText(
            text = buildClockText(
                c, parts.hours, parts.minutes,
                if (seconds) parts.seconds else null,
                if (period) parts.period else null,
                sizeSp
            ),
            style = clockTextStyle(c, sizeSp.sp),
            inkEm = c.font.digitInkEm
        )
    }
}

/**
 * Largest font size (in sp) at which the widest possible time still fits both width and height. Measured
 * from real text layout with the chosen font, so it is correct for every typeface and screen. It uses
 * worst-case digits, so the size stays constant all day instead of changing between 1:11 and 10:08.
 */
private fun fitDigitalSp(
    measurer: TextMeasurer,
    density: Density,
    c: ClockConfig,
    seconds: Boolean,
    period: Boolean,
    availW: Float,
    availH: Float
): Float {
    val base = 100f
    val style = clockTextStyle(c, base.sp)
    val widest = listOf("00", "88").maxOf { digits ->
        val text = buildClockText(c, digits, digits, if (seconds) digits else null, if (period) "AM" else null, base)
        measurer.measure(text, style = style, softWrap = false, maxLines = 1).size.width
    }.toFloat()
    val inkHeight = c.font.digitInkEm * with(density) { base.sp.toPx() }
    val scale = min(availW * 0.98f / widest, availH / inkHeight)
    return (base * scale).coerceAtLeast(24f)
}

// ---------------------------------------------------------------------------------------------------------
// Flip
// ---------------------------------------------------------------------------------------------------------

private class FlipSpec(
    val sizePx: Float,
    val cardW: Float,
    val cardH: Float,
    val gap: Float,
    val sepGap: Float,
    val sepW: Float,
    val periodGap: Float
)

private fun computeFlip(
    measurer: TextMeasurer,
    density: Density,
    c: ClockConfig,
    availW: Float,
    availH: Float
): FlipSpec {
    val basePx = with(density) { 100.sp.toPx() }
    val style = clockTextStyle(c, 100.sp).copy(letterSpacing = 0.sp)
    val digitEm = "0123456789".maxOf { ch ->
        measurer.measure(ch.toString(), style = style, softWrap = false, maxLines = 1).size.width
    }.toFloat() / basePx
    val periodStyle = clockTextStyle(c, 20.sp).copy(fontFamily = c.font.labelFamily, letterSpacing = 0.sp)
    val periodEm = measurer.measure("AM", style = periodStyle, softWrap = false, maxLines = 1).size.width / basePx

    // Everything below is expressed as a multiple of the font size, then scaled to fit.
    val cardW = digitEm + 0.22f
    val cardH = c.font.digitInkEm + 0.42f
    val gap = 0.05f
    val sepGap = 0.06f
    val sepW = 0.16f
    val periodGap = 0.10f
    val groups = if (c.showSeconds) 3 else 2
    val groupW = 2 * cardW + gap
    var total = groups * groupW + (groups - 1) * (sepW + 2 * sepGap)
    if (!c.use24h) total += periodGap + periodEm
    val size = min(availW * 0.98f / total, availH / cardH).coerceAtLeast(24f)
    return FlipSpec(size, cardW * size, cardH * size, gap * size, sepGap * size, sepW * size, periodGap * size)
}

@Composable
private fun FlipFace(c: ClockConfig, now: LocalDateTime) {
    val measurer = rememberTextMeasurer()
    val density = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val availW = constraints.maxWidth.toFloat()
        val availH = constraints.maxHeight.toFloat()
        val spec = remember(c.font, c.weight, c.spacing, c.use24h, c.showSeconds, availW, availH, density) {
            computeFlip(measurer, density, c, availW, availH)
        }
        val parts = timeParts(now, c.use24h, padHours = true)
        val cardW = with(density) { spec.cardW.toDp() }
        val cardH = with(density) { spec.cardH.toDp() }
        val gap = with(density) { spec.gap.toDp() }
        val sepWidth = with(density) { (spec.sepW + 2 * spec.sepGap).toDp() }
        val dot = with(density) { (spec.sizePx * 0.055f).toDp() }
        val radius = with(density) { (spec.sizePx * 0.12f).toDp() }
        val periodGap = with(density) { spec.periodGap.toDp() }
        val sizeSp = with(density) { spec.sizePx.toSp() }

        Row(verticalAlignment = Alignment.CenterVertically) {
            FlipGroup(parts.hours, cardW, cardH, gap, radius, sizeSp, c)
            FlipSeparator(sepWidth, dot, c.color)
            FlipGroup(parts.minutes, cardW, cardH, gap, radius, sizeSp, c)
            if (c.showSeconds) {
                FlipSeparator(sepWidth, dot, c.color)
                FlipGroup(parts.seconds, cardW, cardH, gap, radius, sizeSp, c)
            }
            if (!c.use24h && parts.period != null) {
                Text(
                    text = parts.period,
                    style = clockTextStyle(c, (spec.sizePx * 0.2f).let { with(density) { it.toSp() } })
                        .copy(fontFamily = c.font.labelFamily, letterSpacing = 0.sp, color = c.color.copy(alpha = 0.78f)),
                    maxLines = 1,
                    modifier = Modifier
                        .padding(start = periodGap, bottom = with(density) { (spec.sizePx * 0.06f).toDp() })
                        .align(Alignment.Bottom)
                )
            }
        }
    }
}

@Composable
private fun FlipGroup(text: String, cardW: Dp, cardH: Dp, gap: Dp, radius: Dp, sizeSp: TextUnit, c: ClockConfig) {
    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
        text.forEach { ch -> FlipCard(ch, cardW, cardH, radius, sizeSp, c) }
    }
}

@Composable
private fun FlipCard(ch: Char, w: Dp, h: Dp, radius: Dp, sizeSp: TextUnit, c: ClockConfig) {
    Box(
        Modifier.size(w, h).clip(RoundedCornerShape(radius)).background(c.cardTint),
        contentAlignment = Alignment.Center
    ) {
        InkText(
            text = AnnotatedString(ch.toString()),
            style = clockTextStyle(c, sizeSp).copy(letterSpacing = 0.sp),
            inkEm = c.font.digitInkEm
        )
        // The hinge line that makes it read as a split-flap card.
        Box(Modifier.fillMaxWidth().height(2.dp).background(Color.Black.copy(alpha = 0.35f)))
    }
}

@Composable
private fun FlipSeparator(width: Dp, dot: Dp, color: Color) {
    Column(
        Modifier.width(width),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(dot * 1.6f)
    ) {
        Box(Modifier.size(dot).clip(CircleShape).background(color))
        Box(Modifier.size(dot).clip(CircleShape).background(color))
    }
}

// ---------------------------------------------------------------------------------------------------------
// Analog
// ---------------------------------------------------------------------------------------------------------

@Composable
private fun AnalogFace(c: ClockConfig, now: LocalDateTime) {
    val density = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val sidePx = min(constraints.maxWidth, constraints.maxHeight)
        val side = with(density) { sidePx.toDp() }
        Canvas(Modifier.size(side)) {
            val radius = size.minDimension / 2f * 0.96f
            val center = Offset(size.width / 2f, size.height / 2f)

            fun point(distance: Float, degrees: Float): Offset {
                val rad = Math.toRadians(degrees - 90.0)
                return Offset(center.x + distance * cos(rad).toFloat(), center.y + distance * sin(rad).toFloat())
            }

            drawCircle(c.color.copy(alpha = 0.08f), radius, center)
            drawCircle(c.color.copy(alpha = 0.30f), radius, center, style = Stroke(width = radius * 0.010f))

            for (i in 0 until 60) {
                val major = i % 5 == 0
                val length = radius * if (major) 0.085f else 0.035f
                drawLine(
                    color = c.color.copy(alpha = if (major) 0.95f else 0.45f),
                    start = point(radius * 0.93f - length, i * 6f),
                    end = point(radius * 0.93f, i * 6f),
                    strokeWidth = radius * if (major) 0.022f else 0.010f,
                    cap = StrokeCap.Round
                )
            }

            val secondsDeg = now.second * 6f
            val minutesDeg = (now.minute + now.second / 60f) * 6f
            val hoursDeg = ((now.hour % 12) + now.minute / 60f) * 30f
            drawLine(c.color, point(-radius * 0.08f, hoursDeg), point(radius * 0.50f, hoursDeg), radius * 0.050f, StrokeCap.Round)
            drawLine(c.color, point(-radius * 0.10f, minutesDeg), point(radius * 0.76f, minutesDeg), radius * 0.032f, StrokeCap.Round)
            if (c.showSeconds) {
                drawLine(c.accent, point(-radius * 0.14f, secondsDeg), point(radius * 0.84f, secondsDeg), radius * 0.012f, StrokeCap.Round)
            }
            drawCircle(if (c.showSeconds) c.accent else c.color, radius * 0.035f, center)
        }
    }
}
