package com.cozystand.app

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.text.format.DateFormat
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

internal enum class OrientationMode(val key: String, val label: String) {
    AUTO("auto", "Auto-rotate"),
    LANDSCAPE("landscape", "Landscape"),
    PORTRAIT("portrait", "Portrait");

    companion object {
        fun fromKey(key: String?): OrientationMode = entries.firstOrNull { it.key == key } ?: AUTO
    }
}

internal enum class MediaCardMode(val key: String, val label: String) {
    ALWAYS("always", "Always show"),
    WHEN_ACTIVE("when_active", "Hide when idle");

    companion object {
        fun fromKey(key: String?): MediaCardMode = entries.firstOrNull { it.key == key } ?: ALWAYS
    }
}

/**
 * All user settings. Backed by the same SharedPreferences file ("cozystand") and the same keys the
 * previous version used ("theme", "clock", "24h", "seconds", "wallpaper"), so nothing is lost on upgrade.
 * Every property is Compose state, so the UI updates the moment a setting changes, and every setter
 * persists immediately.
 */
internal class CozyPrefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("cozystand", Context.MODE_PRIVATE)

    var themeIndex by mutableIntStateOf(sp.getInt(K_THEME, DEFAULT_THEME_INDEX).coerceIn(CozyThemes.indices))
        private set
    var clockStyle by mutableStateOf(ClockStyle.fromKey(sp.getString(K_STYLE, null)))
        private set
    var clockFont by mutableStateOf(ClockFont.fromKey(sp.getString(K_FONT, null)))
        private set
    /** The weight the user asked for; the font may snap to its nearest real weight (see [effectiveWeight]). */
    var clockWeight by mutableIntStateOf(sp.getInt(K_WEIGHT, 500))
        private set
    var clockSpacing by mutableStateOf(ClockSpacing.fromKey(sp.getString(K_SPACING, null)))
        private set
    var clockColor by mutableStateOf(ClockColorOption.fromKey(sp.getString(K_COLOR, null)))
        private set
    var use24h by mutableStateOf(sp.getBoolean(K_24H, DateFormat.is24HourFormat(context)))
        private set
    var showSeconds by mutableStateOf(sp.getBoolean(K_SECONDS, false))
        private set
    var wallpaperUri by mutableStateOf(sp.getString(K_WALLPAPER, null)?.let { Uri.parse(it) })
        private set
    var autoColors by mutableStateOf(sp.getBoolean(K_AUTO_COLORS, true))
        private set
    var wallpaperDim by mutableFloatStateOf(sp.getFloat(K_DIM, 0.35f).coerceIn(0f, 0.7f))
        private set
    var mediaMode by mutableStateOf(MediaCardMode.fromKey(sp.getString(K_MEDIA_MODE, null)))
        private set
    var artworkTint by mutableStateOf(sp.getBoolean(K_ART_TINT, true))
        private set
    var keepAwake by mutableStateOf(sp.getBoolean(K_KEEP_AWAKE, true))
        private set
    var orientation by mutableStateOf(OrientationMode.fromKey(sp.getString(K_ORIENTATION, null)))
        private set
    var immersive by mutableStateOf(sp.getBoolean(K_IMMERSIVE, true))
        private set

    val effectiveWeight: Int get() = clockFont.nearestWeight(clockWeight)

    private fun edit(block: (SharedPreferences.Editor) -> Unit) {
        val editor = sp.edit()
        block(editor)
        editor.apply()
    }

    fun updateTheme(index: Int) { themeIndex = index.coerceIn(CozyThemes.indices); edit { it.putInt(K_THEME, themeIndex) } }
    fun updateClockStyle(value: ClockStyle) { clockStyle = value; edit { it.putString(K_STYLE, value.key) } }
    fun updateClockFont(value: ClockFont) { clockFont = value; edit { it.putString(K_FONT, value.key) } }
    fun updateClockWeight(value: Int) { clockWeight = value; edit { it.putInt(K_WEIGHT, value) } }
    fun updateClockSpacing(value: ClockSpacing) { clockSpacing = value; edit { it.putString(K_SPACING, value.key) } }
    fun updateClockColor(value: ClockColorOption) { clockColor = value; edit { it.putString(K_COLOR, value.key) } }
    fun updateUse24h(value: Boolean) { use24h = value; edit { it.putBoolean(K_24H, value) } }
    fun updateShowSeconds(value: Boolean) { showSeconds = value; edit { it.putBoolean(K_SECONDS, value) } }
    fun updateWallpaper(uri: Uri?) {
        wallpaperUri = uri
        edit { if (uri == null) it.remove(K_WALLPAPER) else it.putString(K_WALLPAPER, uri.toString()) }
    }
    fun updateAutoColors(value: Boolean) { autoColors = value; edit { it.putBoolean(K_AUTO_COLORS, value) } }
    fun updateWallpaperDim(value: Float) { wallpaperDim = value.coerceIn(0f, 0.7f); edit { it.putFloat(K_DIM, wallpaperDim) } }
    fun updateMediaMode(value: MediaCardMode) { mediaMode = value; edit { it.putString(K_MEDIA_MODE, value.key) } }
    fun updateArtworkTint(value: Boolean) { artworkTint = value; edit { it.putBoolean(K_ART_TINT, value) } }
    fun updateKeepAwake(value: Boolean) { keepAwake = value; edit { it.putBoolean(K_KEEP_AWAKE, value) } }
    fun updateOrientation(value: OrientationMode) { orientation = value; edit { it.putString(K_ORIENTATION, value.key) } }
    fun updateImmersive(value: Boolean) { immersive = value; edit { it.putBoolean(K_IMMERSIVE, value) } }

    private companion object {
        const val K_THEME = "theme"
        const val K_STYLE = "clock"
        const val K_FONT = "clockFont"
        const val K_WEIGHT = "clockWeight"
        const val K_SPACING = "clockSpacing"
        const val K_COLOR = "clockColor"
        const val K_24H = "24h"
        const val K_SECONDS = "seconds"
        const val K_WALLPAPER = "wallpaper"
        const val K_AUTO_COLORS = "autoColors"
        const val K_DIM = "wallpaperDim"
        const val K_MEDIA_MODE = "mediaMode"
        const val K_ART_TINT = "artTint"
        const val K_KEEP_AWAKE = "keepAwake"
        const val K_ORIENTATION = "orientation"
        const val K_IMMERSIVE = "immersive"
    }
}
