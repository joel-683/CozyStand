package com.cozystand.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.core.graphics.ColorUtils

/**
 * @param sky vertical gradient stops for the built-in background (top to bottom).
 * @param accentOnPhoto accent used when a wallpaper photo is showing (always light enough for a dark scrim).
 * @param surface base surface colour for the settings screen.
 */
@Immutable
internal data class CozyTheme(
    val name: String,
    val sky: List<Color>,
    val hillBack: Color,
    val hillFront: Color,
    val accent: Color,
    val accentOnPhoto: Color,
    val text: Color,
    val surface: Color,
    val light: Boolean
)

// Order matters: the index is persisted under "theme", so existing installs keep their choice.
internal val CozyThemes: List<CozyTheme> = listOf(
    CozyTheme(
        "Oat milk",
        listOf(Color(0xFFF4EBDD), Color(0xFFE6D8C0), Color(0xFFD2BF9F), Color(0xFFB8A283)),
        Color(0x66A58E70), Color(0x88826C55),
        Color(0xFF594B3E), Color(0xFFF2D9AE), Color(0xFF29241F), Color(0xFFF7F0E4), light = true
    ),
    CozyTheme(
        "Walnut",
        listOf(Color(0xFF5E4A3B), Color(0xFF46362D), Color(0xFF2C221D), Color(0xFF171210)),
        Color(0x884A392F), Color(0xCC1F1814),
        Color(0xFFD6B58C), Color(0xFFD6B58C), Color(0xFFF4E8D8), Color(0xFF1E1917), light = false
    ),
    CozyTheme(
        "Moss",
        listOf(Color(0xFF3F5742), Color(0xFF354638), Color(0xFF223228), Color(0xFF111B15)),
        Color(0x88304234), Color(0xCC121F18),
        Color(0xFFB5C19A), Color(0xFFB5C19A), Color(0xFFF0EBDD), Color(0xFF17241E), light = false
    ),
    CozyTheme(
        "Dusk",
        listOf(Color(0xFF251B50), Color(0xFF9B477B), Color(0xFF22264C), Color(0xFF080F28)),
        Color(0xAA20264F), Color(0xDD101A3B),
        Color(0xFFCDBBFF), Color(0xFFCDBBFF), Color(0xFFFFF3EA), Color(0xFF14122E), light = false
    ),
    CozyTheme(
        "Terracotta",
        listOf(Color(0xFFD38A68), Color(0xFFB96F50), Color(0xFF7A4338), Color(0xFF3A201E)),
        Color(0x88603A32), Color(0xCC2E1917),
        Color(0xFFFFD5B8), Color(0xFFFFD5B8), Color(0xFFFFF0E5), Color(0xFF2F1A18), light = false
    ),
    CozyTheme(
        "Midnight",
        listOf(Color(0xFF2B3140), Color(0xFF252A35), Color(0xFF171B24), Color(0xFF0B0D12)),
        Color(0x881B2230), Color(0xCC0C1017),
        Color(0xFFB9C8D9), Color(0xFFB9C8D9), Color(0xFFEAF0F6), Color(0xFF101319), light = false
    )
)

internal const val DEFAULT_THEME_INDEX = 3 // Dusk

/** Colours the standby screen actually draws with, after the theme, wallpaper and auto-colour rules. */
@Immutable
internal data class StandbyPalette(
    val foreground: Color,
    val accent: Color,
    val cardSurface: Color,
    val onCard: Color,
    val cardBorder: Color,
    val flipCard: Color
)

internal fun buildPalette(theme: CozyTheme, hasWallpaper: Boolean, autoAccent: Color?): StandbyPalette {
    val warmWhite = Color(0xFFFFF8F1)
    return when {
        hasWallpaper -> StandbyPalette(
            foreground = warmWhite,
            accent = autoAccent ?: theme.accentOnPhoto,
            cardSurface = Color(0xFF0B0B14).copy(alpha = 0.42f),
            onCard = warmWhite,
            cardBorder = warmWhite.copy(alpha = 0.14f),
            flipCard = Color.Black.copy(alpha = 0.30f)
        )
        theme.light -> StandbyPalette(
            foreground = theme.text,
            accent = theme.accent,
            cardSurface = Color.White.copy(alpha = 0.55f),
            onCard = theme.text,
            cardBorder = theme.text.copy(alpha = 0.10f),
            flipCard = Color.White.copy(alpha = 0.50f)
        )
        else -> StandbyPalette(
            foreground = theme.text,
            accent = theme.accent,
            cardSurface = Color(0xFF05050F).copy(alpha = 0.30f),
            onCard = theme.text,
            cardBorder = theme.text.copy(alpha = 0.12f),
            flipCard = Color.Black.copy(alpha = 0.30f)
        )
    }
}

private fun blend(base: Color, over: Color, amount: Float): Color =
    Color(ColorUtils.blendARGB(base.toArgb(), over.toArgb(), amount))

/** Material 3 scheme for the settings screen and dialogs, derived from the selected theme. */
internal fun cozyColorScheme(theme: CozyTheme, accent: Color): ColorScheme {
    val surface = theme.surface
    val text = theme.text
    val onAccent = if (accent.luminanceCompat() > 0.5f) Color(0xFF1B1530) else Color.White
    val tonal = blend(surface, accent, 0.22f)
    val variantText = blend(text, surface, 0.32f)
    val outline = blend(text, surface, 0.55f)
    val outlineVariant = blend(text, surface, 0.82f)
    return if (theme.light) {
        lightColorScheme(
            primary = accent, onPrimary = onAccent,
            primaryContainer = tonal, onPrimaryContainer = text,
            secondary = accent, onSecondary = onAccent,
            secondaryContainer = tonal, onSecondaryContainer = text,
            tertiary = accent, onTertiary = onAccent,
            background = surface, onBackground = text,
            surface = surface, onSurface = text,
            surfaceVariant = blend(surface, Color.Black, 0.06f), onSurfaceVariant = variantText,
            surfaceTint = accent,
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = blend(surface, Color.Black, 0.02f),
            surfaceContainer = blend(surface, Color.Black, 0.05f),
            surfaceContainerHigh = blend(surface, Color.Black, 0.08f),
            surfaceContainerHighest = blend(surface, Color.Black, 0.12f),
            outline = outline, outlineVariant = outlineVariant
        )
    } else {
        darkColorScheme(
            primary = accent, onPrimary = onAccent,
            primaryContainer = tonal, onPrimaryContainer = text,
            secondary = accent, onSecondary = onAccent,
            secondaryContainer = tonal, onSecondaryContainer = text,
            tertiary = accent, onTertiary = onAccent,
            background = surface, onBackground = text,
            surface = surface, onSurface = text,
            surfaceVariant = blend(surface, Color.White, 0.10f), onSurfaceVariant = variantText,
            surfaceTint = accent,
            surfaceContainerLowest = blend(surface, Color.Black, 0.30f),
            surfaceContainerLow = blend(surface, Color.White, 0.03f),
            surfaceContainer = blend(surface, Color.White, 0.06f),
            surfaceContainerHigh = blend(surface, Color.White, 0.10f),
            surfaceContainerHighest = blend(surface, Color.White, 0.14f),
            outline = outline, outlineVariant = outlineVariant
        )
    }
}

internal fun Color.luminanceCompat(): Float = ColorUtils.calculateLuminance(this.toArgb()).toFloat()

/** Material 3 typography with the bundled UI family applied to every role. */
internal fun cozyTypography(family: FontFamily): Typography {
    val d = Typography()
    return d.copy(
        displayLarge = d.displayLarge.copy(fontFamily = family),
        displayMedium = d.displayMedium.copy(fontFamily = family),
        displaySmall = d.displaySmall.copy(fontFamily = family),
        headlineLarge = d.headlineLarge.copy(fontFamily = family),
        headlineMedium = d.headlineMedium.copy(fontFamily = family),
        headlineSmall = d.headlineSmall.copy(fontFamily = family),
        titleLarge = d.titleLarge.copy(fontFamily = family),
        titleMedium = d.titleMedium.copy(fontFamily = family),
        titleSmall = d.titleSmall.copy(fontFamily = family),
        bodyLarge = d.bodyLarge.copy(fontFamily = family),
        bodyMedium = d.bodyMedium.copy(fontFamily = family),
        bodySmall = d.bodySmall.copy(fontFamily = family),
        labelLarge = d.labelLarge.copy(fontFamily = family),
        labelMedium = d.labelMedium.copy(fontFamily = family),
        labelSmall = d.labelSmall.copy(fontFamily = family)
    )
}

/** Full-screen background: the user's photo with an adjustable dim, or the theme's gradient and hills. */
@Composable
internal fun StandbyBackground(
    theme: CozyTheme,
    wallpaper: ImageBitmap?,
    dim: Float,
    modifier: Modifier = Modifier
) {
    Box(modifier.background(Brush.verticalGradient(theme.sky))) {
        if (wallpaper != null) {
            Image(
                bitmap = wallpaper,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            // Always keep a readable scrim, then let the user add more.
            val top = (0.10f + dim * 0.5f).coerceIn(0f, 0.9f)
            val bottom = (0.30f + dim * 0.7f).coerceIn(0f, 0.92f)
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Black.copy(alpha = top), Color.Black.copy(alpha = bottom)))
                )
            )
        } else {
            Hills(theme)
        }
    }
}

@Composable
private fun Hills(theme: CozyTheme) {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val back = Path().apply {
            moveTo(0f, h * .57f)
            cubicTo(w * .18f, h * .47f, w * .24f, h * .38f, w * .39f, h * .55f)
            cubicTo(w * .56f, h * .70f, w * .73f, h * .43f, w, h * .54f)
            lineTo(w, h); lineTo(0f, h); close()
        }
        val front = Path().apply {
            moveTo(0f, h * .68f)
            cubicTo(w * .2f, h * .54f, w * .3f, h * .66f, w * .48f, h * .72f)
            cubicTo(w * .68f, h * .79f, w * .82f, h * .58f, w, h * .66f)
            lineTo(w, h); lineTo(0f, h); close()
        }
        drawPath(back, theme.hillBack)
        drawPath(front, theme.hillFront)
    }
}
