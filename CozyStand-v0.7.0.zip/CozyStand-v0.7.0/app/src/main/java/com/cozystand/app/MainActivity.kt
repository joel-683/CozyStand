package com.cozystand.app

import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Draw edge to edge; the Compose layouts apply the safe-drawing insets themselves.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        setContent { CozyStandApp(this) }
    }
}

@Composable
internal fun CozyStandApp(activity: ComponentActivity) {
    val context = LocalContext.current
    val prefs = remember { CozyPrefs(context) }
    val monitor = remember { MediaMonitor(context) }
    var showSettings by rememberSaveable { mutableStateOf(false) }

    val theme = CozyThemes[prefs.themeIndex]

    // Wallpaper: decoded off the main thread, scaled to a safe size, accent colour sampled from it.
    var wallpaper by remember { mutableStateOf<ImageBitmap?>(null) }
    var wallpaperAccent by remember { mutableStateOf<Color?>(null) }
    LaunchedEffect(prefs.wallpaperUri) {
        wallpaper = null
        wallpaperAccent = null
        val uri = prefs.wallpaperUri ?: return@LaunchedEffect
        loadWallpaper(context, uri)?.let {
            wallpaper = it.image
            wallpaperAccent = it.accent
        }
    }
    val hasWallpaper = wallpaper != null
    val autoAccent = if (prefs.autoColors) wallpaperAccent else null
    val palette = remember(theme, hasWallpaper, autoAccent) { buildPalette(theme, hasWallpaper, autoAccent) }

    // Window behaviour driven by settings.
    val window = activity.window
    val barsController = remember { WindowInsetsControllerCompat(window, window.decorView) }
    val applyBars: () -> Unit = {
        barsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (prefs.immersive) {
            barsController.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            barsController.show(WindowInsetsCompat.Type.systemBars())
        }
    }
    LaunchedEffect(prefs.immersive) { applyBars() }
    LaunchedEffect(prefs.keepAwake) {
        if (prefs.keepAwake) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
    LaunchedEffect(prefs.orientation) {
        activity.requestedOrientation = when (prefs.orientation) {
            OrientationMode.AUTO -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            OrientationMode.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            OrientationMode.PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }
    }
    // Dark system-bar icons on a light background, light icons otherwise.
    val lightBars = if (showSettings) theme.light else theme.light && !hasWallpaper
    SideEffect {
        barsController.isAppearanceLightStatusBars = lightBars
        barsController.isAppearanceLightNavigationBars = lightBars
    }

    // Media session lifetime follows the activity: listen while visible, release when stopped.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, monitor) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> monitor.start()
                Lifecycle.Event.ON_RESUME -> {
                    monitor.refresh() // picks up a permission change made in Android settings
                    applyBars()
                }
                Lifecycle.Event.ON_STOP -> monitor.stop()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            monitor.stop()
        }
    }
    // Safety net for session or permission changes that arrive without a callback.
    LaunchedEffect(monitor) {
        while (true) {
            delay(4000)
            monitor.refresh()
        }
    }

    val pickWallpaper = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            prefs.updateWallpaper(uri)
        }
    }
    val openNotificationAccess: () -> Unit = {
        runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
    }
    val openAppInfo: () -> Unit = {
        runCatching {
            context.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            )
        }
    }

    // On a light theme the settings screen needs the darker accent even when a photo supplies a light one.
    val schemeAccent = if (theme.light) theme.accent else palette.accent
    val colorScheme = remember(theme, schemeAccent) { cozyColorScheme(theme, schemeAccent) }
    val typography = remember { cozyTypography(UiFontFamily) }

    MaterialTheme(colorScheme = colorScheme, typography = typography) {
        Box(Modifier.fillMaxSize().background(theme.surface)) {
            StandbyScreen(
                prefs = prefs,
                theme = theme,
                palette = palette,
                wallpaper = wallpaper,
                media = monitor.state,
                onPrevious = monitor::skipToPrevious,
                onPlayPause = monitor::togglePlayPause,
                onNext = monitor::skipToNext,
                onOpenAccessSettings = openNotificationAccess,
                onOpenSettings = { showSettings = true }
            )

            BackHandler(enabled = showSettings) { showSettings = false }
            AnimatedVisibility(
                visible = showSettings,
                enter = fadeIn(tween(200)) + slideInVertically(tween(260)) { it / 14 },
                exit = fadeOut(tween(160)) + slideOutVertically(tween(200)) { it / 14 }
            ) {
                SettingsScreen(
                    prefs = prefs,
                    theme = theme,
                    palette = palette,
                    wallpaper = wallpaper,
                    media = monitor.state,
                    onPickWallpaper = { pickWallpaper.launch(arrayOf("image/*")) },
                    onOpenNotificationAccess = openNotificationAccess,
                    onOpenAppInfo = openAppInfo,
                    onBack = { showSettings = false },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
