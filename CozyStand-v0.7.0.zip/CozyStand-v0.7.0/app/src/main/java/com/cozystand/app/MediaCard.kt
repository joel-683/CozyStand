package com.cozystand.app

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private data class CardText(val title: String, val subtitle: String)

private fun cardText(m: MediaUiState): CardText = when {
    !m.accessGranted -> CardText("Allow media access", "Let CozyStand see what is playing")
    !m.hasSession -> CardText("Nothing playing", "Start music or a video in any app")
    m.title != null -> CardText(m.title, m.artist ?: m.album ?: m.appLabel.orEmpty())
    else -> CardText(m.appLabel ?: "Media", if (m.isPlaying) "Playing" else "Paused")
}

/**
 * The standby media player. Reads a real [MediaUiState]; the buttons drive the real MediaSession.
 * Wide layout on tablets (artwork | title + progress | controls), stacked layout on narrow widths.
 *
 * @param dense use smaller artwork and padding when the screen is short (phones in landscape).
 */
@Composable
internal fun MediaCard(
    media: MediaUiState,
    palette: StandbyPalette,
    artworkTint: Boolean,
    dense: Boolean,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onOpenAccessSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val artAccent = rememberArtAccent(media.art, artworkTint)
    val accent by animateColorAsState(artAccent ?: palette.accent, animationSpec = tween(500), label = "cardAccent")
    val shape = RoundedCornerShape(if (dense) 24.dp else 32.dp)
    val text = cardText(media)

    BoxWithConstraints(modifier) {
        // Captured here, in the BoxWithConstraints scope, and passed down explicitly.
        val compact = maxWidth < 560.dp
        Box(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(palette.cardSurface)
                .background(Brush.verticalGradient(listOf(palette.onCard.copy(alpha = 0.07f), Color.Transparent)))
                .border(1.dp, palette.cardBorder, shape)
        ) {
            if (compact) {
                Column(
                    Modifier.fillMaxWidth().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Artwork(media.art, accent, 72.dp)
                        Column(Modifier.weight(1f)) { TitleBlock(text, palette.onCard, titleSp = 18f, subtitleSp = 14f) }
                    }
                    ProgressBlock(media, accent, palette.onCard)
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        CardActions(media, accent, palette.onCard, 64.dp, 52.dp, onPrevious, onPlayPause, onNext, onOpenAccessSettings)
                    }
                }
            } else {
                val artSize = if (dense) 76.dp else 112.dp
                Row(
                    Modifier.fillMaxWidth().padding(if (dense) 12.dp else 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(if (dense) 16.dp else 22.dp)
                ) {
                    Artwork(media.art, accent, artSize)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        TitleBlock(
                            text, palette.onCard,
                            titleSp = if (dense) 18f else 22f,
                            subtitleSp = if (dense) 14f else 16f
                        )
                        Spacer(Modifier.height(if (dense) 8.dp else 14.dp))
                        ProgressBlock(media, accent, palette.onCard)
                    }
                    CardActions(
                        media, accent, palette.onCard,
                        playSize = if (dense) 56.dp else 68.dp,
                        sideSize = if (dense) 48.dp else 52.dp,
                        onPrevious, onPlayPause, onNext, onOpenAccessSettings
                    )
                }
            }
        }
    }
}

@Composable
private fun TitleBlock(text: CardText, onCard: Color, titleSp: Float, subtitleSp: Float) {
    Text(
        text.title,
        color = onCard,
        fontSize = titleSp.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
    )
    if (text.subtitle.isNotEmpty()) {
        Text(
            text.subtitle,
            color = onCard.copy(alpha = 0.72f),
            fontSize = subtitleSp.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Square, rounded artwork. [ContentScale.Crop] fills the square without ever stretching the picture. */
@Composable
private fun Artwork(art: Bitmap?, accent: Color, size: Dp, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(size * 0.2f)
    Box(
        modifier
            .size(size)
            .clip(shape)
            .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.34f), accent.copy(alpha = 0.12f))))
    ) {
        Crossfade(targetState = art, animationSpec = tween(350), modifier = Modifier.fillMaxSize(), label = "artwork") { bitmap ->
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (bitmap != null) {
                    val image = remember(bitmap) { bitmap.asImageBitmap() }
                    Image(
                        bitmap = image,
                        contentDescription = "Album artwork",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    // Designed fallback for sessions that supply no artwork.
                    Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = accent, modifier = Modifier.size(size * 0.42f))
                }
            }
        }
    }
}

/** Progress is drawn only from the player's real position and duration. Unknown values are never faked. */
@Composable
private fun ProgressBlock(media: MediaUiState, accent: Color, onCard: Color) {
    val position = rememberPlaybackPosition(media)
    val fraction = if (media.hasProgress && position >= 0) {
        (position.toFloat() / media.durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val shown by animateFloatAsState(fraction, animationSpec = tween(450, easing = LinearEasing), label = "progress")

    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(onCard.copy(alpha = 0.18f))) {
            Box(Modifier.fillMaxWidth(shown).fillMaxHeight().clip(CircleShape).background(accent))
        }
        // Fixed height so the card does not change size when a player has no duration.
        Box(Modifier.fillMaxWidth().height(20.dp).padding(top = 4.dp)) {
            if (media.hasProgress && position >= 0) {
                Text(formatTime(position), color = onCard.copy(alpha = 0.66f), fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterStart))
                Text(formatTime(media.durationMs), color = onCard.copy(alpha = 0.66f), fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterEnd))
            }
        }
    }
}

@Composable
private fun rememberPlaybackPosition(media: MediaUiState): Long {
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(media.isPlaying, media.positionMs, media.positionUpdateTime, media.durationMs) {
        now = SystemClock.elapsedRealtime()
        while (media.isPlaying && media.hasProgress) {
            delay(500)
            now = SystemClock.elapsedRealtime()
        }
    }
    return media.positionAt(now)
}

private fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    val ss = s.toString().padStart(2, '0')
    return if (h > 0) "$h:${m.toString().padStart(2, '0')}:$ss" else "$m:$ss"
}

@Composable
private fun CardActions(
    media: MediaUiState,
    accent: Color,
    onCard: Color,
    playSize: Dp,
    sideSize: Dp,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onOpenAccessSettings: () -> Unit
) {
    val onAccent = if (accent.luminanceCompat() > 0.5f) Color(0xFF1B1530) else Color.White
    if (!media.accessGranted) {
        FilledTonalButton(
            onClick = onOpenAccessSettings,
            colors = ButtonDefaults.filledTonalButtonColors(containerColor = accent, contentColor = onAccent)
        ) { Text("Allow access") }
        return
    }
    val enabled = media.hasSession
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        IconButton(
            onClick = onPrevious,
            enabled = enabled && media.canPrevious,
            modifier = Modifier.size(sideSize),
            colors = IconButtonDefaults.iconButtonColors(contentColor = onCard, disabledContentColor = onCard.copy(alpha = 0.30f))
        ) { Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous track", modifier = Modifier.size(sideSize * 0.58f)) }

        FilledIconButton(
            onClick = onPlayPause,
            enabled = enabled,
            modifier = Modifier.size(playSize),
            shape = CircleShape,
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = accent,
                contentColor = onAccent,
                disabledContainerColor = onCard.copy(alpha = 0.12f),
                disabledContentColor = onCard.copy(alpha = 0.30f)
            )
        ) {
            Crossfade(targetState = media.isPlaying, animationSpec = tween(160), label = "playPause") { playing ->
                Icon(
                    if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (playing) "Pause" else "Play",
                    modifier = Modifier.size(playSize * 0.52f)
                )
            }
        }

        IconButton(
            onClick = onNext,
            enabled = enabled && media.canNext,
            modifier = Modifier.size(sideSize),
            colors = IconButtonDefaults.iconButtonColors(contentColor = onCard, disabledContentColor = onCard.copy(alpha = 0.30f))
        ) { Icon(Icons.Rounded.SkipNext, contentDescription = "Next track", modifier = Modifier.size(sideSize * 0.58f)) }
    }
}

/** Samples a colour from the current artwork off the main thread. Null until ready or when disabled. */
@Composable
private fun rememberArtAccent(art: Bitmap?, enabled: Boolean): Color? {
    var accent by remember { mutableStateOf<Color?>(null) }
    LaunchedEffect(art, enabled) {
        accent = if (enabled && art != null) {
            withContext(Dispatchers.Default) { runCatching { extractAccent(art) }.getOrNull() }
        } else {
            null
        }
    }
    return accent
}
