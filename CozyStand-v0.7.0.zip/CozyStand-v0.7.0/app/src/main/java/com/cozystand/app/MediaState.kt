package com.cozystand.app

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationManagerCompat
import kotlin.math.max

/**
 * Snapshot of the active media session. Everything here comes from Android's MediaSession APIs;
 * nothing is invented. A field is null / negative when the player did not provide it.
 */
@Immutable
internal data class MediaUiState(
    /** True when CozyStand is enabled under Notification access (required to see other apps' sessions). */
    val accessGranted: Boolean = false,
    val hasSession: Boolean = false,
    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    val art: Bitmap? = null,
    val appPackage: String? = null,
    val appLabel: String? = null,
    val isPlaying: Boolean = false,
    /** Track length in ms, or -1 when unknown (live streams, some video apps). */
    val durationMs: Long = -1L,
    /** Position in ms at [positionUpdateTime], or -1 when the player does not report one. */
    val positionMs: Long = -1L,
    /** [android.os.SystemClock.elapsedRealtime] timestamp when [positionMs] was captured. */
    val positionUpdateTime: Long = 0L,
    val speed: Float = 1f,
    val canPrevious: Boolean = false,
    val canNext: Boolean = false
) {
    val hasProgress: Boolean get() = durationMs > 0 && positionMs >= 0

    /** Live position extrapolated from the last report, using the player's own playback speed. */
    fun positionAt(nowElapsed: Long): Long {
        if (positionMs < 0) return -1L
        val extrapolated = if (isPlaying && positionUpdateTime > 0L) {
            positionMs + ((nowElapsed - positionUpdateTime) * speed).toLong()
        } else {
            positionMs
        }
        return if (durationMs > 0) extrapolated.coerceIn(0L, durationMs) else max(0L, extrapolated)
    }
}

/**
 * Observes Android's active media sessions (YouTube, YouTube Music, Spotify, VLC and anything else that
 * publishes a MediaSession) and exposes them as Compose state. Uses session/metadata/playback callbacks
 * rather than polling. Requires the user to enable Notification access for [MediaSessionNotificationListener].
 */
internal class MediaMonitor(context: Context) {
    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val listenerComponent = ComponentName(appContext, MediaSessionNotificationListener::class.java)

    var state by mutableStateOf(MediaUiState())
        private set

    private var controller: MediaController? = null
    private var started = false
    private var registered = false
    private var lastArtKey: String? = null
    private var lastArt: Bitmap? = null
    private val labelCache = HashMap<String, String>()

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers -> onSessions(controllers.orEmpty()) }

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onSessionDestroyed() = refresh()
    }

    fun start() {
        started = true
        refresh()
    }

    fun stop() {
        started = false
        unregister()
        setController(null)
    }

    /** Re-checks the permission and the list of sessions. Cheap enough to call every few seconds. */
    fun refresh() {
        if (!started) return
        if (!isAccessGranted()) {
            unregister()
            setController(null)
            state = MediaUiState(accessGranted = false)
            return
        }
        if (!registered) {
            registered = runCatching {
                manager.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent)
            }.isSuccess
        }
        val sessions = runCatching { manager.getActiveSessions(listenerComponent) }.getOrDefault(emptyList())
        onSessions(sessions)
    }

    fun togglePlayPause() {
        val controls = controller?.transportControls ?: return
        if (state.isPlaying) controls.pause() else controls.play()
    }

    fun skipToNext() { controller?.transportControls?.skipToNext() }

    fun skipToPrevious() { controller?.transportControls?.skipToPrevious() }

    private fun isAccessGranted(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(appContext).contains(appContext.packageName)

    private fun unregister() {
        if (registered) {
            runCatching { manager.removeOnActiveSessionsChangedListener(sessionsListener) }
            registered = false
        }
    }

    private fun onSessions(sessions: List<MediaController>) {
        // Prefer whatever is actually playing; otherwise stay on the session we already show.
        val chosen = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: sessions.firstOrNull { current -> controller?.sessionToken == current.sessionToken }
            ?: sessions.firstOrNull()
        val changed = setController(chosen)
        if (changed || chosen == null) publish()
    }

    /** @return true when the observed session changed. */
    private fun setController(next: MediaController?): Boolean {
        if (controller?.sessionToken == next?.sessionToken) return false
        runCatching { controller?.unregisterCallback(callback) }
        controller = next
        runCatching { next?.registerCallback(callback) }
        return true
    }

    private fun publish() {
        val c = controller
        if (c == null) {
            state = MediaUiState(accessGranted = isAccessGranted())
            return
        }
        val metadata = c.metadata
        val playback = c.playbackState

        val title = metadata?.text(MediaMetadata.METADATA_KEY_TITLE)
            ?: metadata?.text(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        val artist = metadata?.text(MediaMetadata.METADATA_KEY_ARTIST)
            ?: metadata?.text(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: metadata?.text(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
        val album = metadata?.text(MediaMetadata.METADATA_KEY_ALBUM)
        val duration = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

        // Reading metadata re-parcels the bitmap on every call. Keep the previous instance while the track
        // is unchanged so the UI does not re-fade the same picture each time playback state changes.
        val artKey = listOf(title, artist, album, metadata?.getString(MediaMetadata.METADATA_KEY_MEDIA_ID), duration)
            .joinToString("|")
        val art: Bitmap? = if (artKey == lastArtKey && lastArt != null) {
            lastArt
        } else {
            val raw = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            val prepared = raw?.let { runCatching { trimBlackBars(it) }.getOrDefault(it) }
            lastArtKey = artKey
            lastArt = prepared
            prepared
        }

        val actions = playback?.actions ?: 0L
        val playbackState = playback?.state ?: PlaybackState.STATE_NONE
        val position = playback?.position ?: PlaybackState.PLAYBACK_POSITION_UNKNOWN
        // Some apps never fill in the supported-actions mask; in that case do not disable anything.
        val maskKnown = actions != 0L

        state = MediaUiState(
            accessGranted = true,
            hasSession = true,
            title = title,
            artist = artist,
            album = album,
            art = art,
            appPackage = c.packageName,
            appLabel = labelFor(c.packageName),
            isPlaying = playbackState == PlaybackState.STATE_PLAYING ||
                playbackState == PlaybackState.STATE_BUFFERING,
            durationMs = if (duration > 0) duration else -1L,
            positionMs = if (position >= 0) position else -1L,
            positionUpdateTime = playback?.lastPositionUpdateTime ?: 0L,
            speed = playback?.playbackSpeed?.takeIf { it > 0f } ?: 1f,
            canPrevious = !maskKnown || actions and PlaybackState.ACTION_SKIP_TO_PREVIOUS != 0L,
            canNext = !maskKnown || actions and PlaybackState.ACTION_SKIP_TO_NEXT != 0L
        )
    }

    private fun MediaMetadata.text(key: String): String? = getString(key)?.trim()?.takeIf { it.isNotEmpty() }

    private fun labelFor(packageName: String): String = labelCache.getOrPut(packageName) {
        runCatching {
            val pm = appContext.packageManager
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            pm.getApplicationLabel(info).toString()
        }.getOrElse { KnownPlayers[packageName] ?: packageName.substringAfterLast('.').replaceFirstChar { it.uppercase() } }
    }

    private companion object {
        /** Fallback names for when Android's package-visibility rules hide the app's real label. */
        val KnownPlayers = mapOf(
            "com.google.android.youtube" to "YouTube",
            "com.google.android.apps.youtube.music" to "YouTube Music",
            "com.spotify.music" to "Spotify",
            "org.videolan.vlc" to "VLC",
            "com.amazon.mp3" to "Amazon Music",
            "deezer.android.app" to "Deezer",
            "com.apple.android.music" to "Apple Music"
        )
    }
}

/**
 * Video apps often hand over thumbnails with black letterbox bars baked in. Cropping a square out of that
 * would show the bars, so trim any solid-black edge first. Returns the original when nothing is trimmed.
 */
internal fun trimBlackBars(src: Bitmap): Bitmap {
    val w = src.width
    val h = src.height
    if (w < 16 || h < 16 || src.config == Bitmap.Config.HARDWARE) return src

    fun rowIsBlack(y: Int): Boolean {
        val px = IntArray(w)
        src.getPixels(px, 0, w, 0, y, w, 1)
        return px.all { isNearBlack(it) }
    }
    fun columnIsBlack(x: Int): Boolean {
        val px = IntArray(h)
        src.getPixels(px, 0, 1, x, 0, 1, h)
        return px.all { isNearBlack(it) }
    }

    var top = 0
    while (top < h / 3 && rowIsBlack(top)) top++
    var bottom = 0
    while (bottom < h / 3 && rowIsBlack(h - 1 - bottom)) bottom++
    var left = 0
    while (left < w / 3 && columnIsBlack(left)) left++
    var right = 0
    while (right < w / 3 && columnIsBlack(w - 1 - right)) right++

    // Ignore hairline borders; only act on real bars.
    val minBarY = h * 0.03f
    val minBarX = w * 0.03f
    if (top < minBarY) top = 0
    if (bottom < minBarY) bottom = 0
    if (left < minBarX) left = 0
    if (right < minBarX) right = 0
    if (top == 0 && bottom == 0 && left == 0 && right == 0) return src

    val newW = w - left - right
    val newH = h - top - bottom
    if (newW < w * 0.4f || newH < h * 0.4f) return src
    return Bitmap.createBitmap(src, left, top, newW, newH)
}

private fun isNearBlack(argb: Int): Boolean =
    AndroidColor.alpha(argb) < 20 ||
        (AndroidColor.red(argb) < 18 && AndroidColor.green(argb) < 18 && AndroidColor.blue(argb) < 18)
