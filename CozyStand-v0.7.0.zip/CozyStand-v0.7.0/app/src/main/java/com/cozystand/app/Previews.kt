package com.cozystand.app

import android.os.SystemClock
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview

// Android Studio previews only. The sample MediaUiState below is never used by the running app, which reads
// real data from MediaMonitor.

private val SampleMedia = MediaUiState(
    accessGranted = true,
    hasSession = true,
    title = "Aaradhana (Live)",
    artist = "Elevation Worship",
    appLabel = "YouTube Music",
    isPlaying = true,
    durationMs = 324_000L,
    positionMs = 151_000L,
    positionUpdateTime = SystemClock.elapsedRealtime(),
    canPrevious = true,
    canNext = true
)

@Composable
private fun PreviewHost(content: @Composable (CozyPrefs, CozyTheme, StandbyPalette) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { CozyPrefs(context) }
    val theme = CozyThemes[DEFAULT_THEME_INDEX]
    val palette = remember { buildPalette(theme, hasWallpaper = false, autoAccent = null) }
    MaterialTheme(colorScheme = cozyColorScheme(theme, palette.accent), typography = cozyTypography(UiFontFamily)) {
        content(prefs, theme, palette)
    }
}

@Composable
private fun StandbyPreviewContent(media: MediaUiState) = PreviewHost { prefs, theme, palette ->
    StandbyScreen(
        prefs = prefs, theme = theme, palette = palette, wallpaper = null, media = media,
        onPrevious = {}, onPlayPause = {}, onNext = {}, onOpenAccessSettings = {}, onOpenSettings = {}
    )
}

@Preview(name = "Tablet landscape (3:2)", device = "spec:width=1067dp,height=711dp,dpi=345")
@Composable
private fun StandbyTabletPreview() = StandbyPreviewContent(SampleMedia)

@Preview(name = "Tablet, nothing playing", device = "spec:width=1067dp,height=711dp,dpi=345")
@Composable
private fun StandbyTabletIdlePreview() = StandbyPreviewContent(MediaUiState(accessGranted = true))

@Preview(name = "Tablet, access needed", device = "spec:width=1067dp,height=711dp,dpi=345")
@Composable
private fun StandbyTabletNoAccessPreview() = StandbyPreviewContent(MediaUiState())

@Preview(name = "Phone portrait", device = "spec:width=360dp,height=780dp,dpi=420")
@Composable
private fun StandbyPhonePreview() = StandbyPreviewContent(SampleMedia)

@Preview(name = "Phone landscape", device = "spec:width=780dp,height=360dp,dpi=420")
@Composable
private fun StandbyPhoneLandscapePreview() = StandbyPreviewContent(SampleMedia)

@Preview(name = "Settings, tablet", device = "spec:width=1067dp,height=711dp,dpi=345")
@Composable
private fun SettingsTabletPreview() = PreviewHost { prefs, theme, palette ->
    SettingsScreen(prefs, theme, palette, null, SampleMedia, {}, {}, {}, {})
}

@Preview(name = "Settings, phone", device = "spec:width=360dp,height=780dp,dpi=420")
@Composable
private fun SettingsPhonePreview() = PreviewHost { prefs, theme, palette ->
    SettingsScreen(prefs, theme, palette, null, MediaUiState(), {}, {}, {}, {})
}
