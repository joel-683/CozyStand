@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.cozystand.app

import android.content.Context
import android.os.Build
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Brightness6
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ColorLens
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Wallpaper
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val CardPadding = Modifier.padding(horizontal = 20.dp)

/**
 * Full-page settings. Everything scrolls vertically, the system-bar insets are applied by [Scaffold],
 * and on wide screens the live clock preview stays pinned beside the list so changes are visible at once.
 */
@Composable
internal fun SettingsScreen(
    prefs: CozyPrefs,
    theme: CozyTheme,
    palette: StandbyPalette,
    wallpaper: ImageBitmap?,
    media: MediaUiState,
    onPickWallpaper: () -> Unit,
    onOpenNotificationAccess: () -> Unit,
    onOpenAppInfo: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        BoxWithConstraints(Modifier.padding(innerPadding).fillMaxSize()) {
            val twoPane = maxWidth >= 900.dp
            if (twoPane) {
                Row(Modifier.fillMaxSize()) {
                    Column(Modifier.weight(0.42f).fillMaxHeight().padding(start = 24.dp, end = 8.dp, top = 8.dp)) {
                        ClockPreview(prefs, theme, palette, wallpaper, Modifier.fillMaxWidth().height(300.dp))
                    }
                    SettingsList(
                        Modifier.weight(0.58f).fillMaxHeight(),
                        prefs, theme, palette, wallpaper, media,
                        showPreview = false,
                        onPickWallpaper, onOpenNotificationAccess, onOpenAppInfo
                    )
                }
            } else {
                SettingsList(
                    Modifier.fillMaxSize(),
                    prefs, theme, palette, wallpaper, media,
                    showPreview = true,
                    onPickWallpaper, onOpenNotificationAccess, onOpenAppInfo
                )
            }
        }
    }
}

@Composable
private fun ClockPreview(
    prefs: CozyPrefs,
    theme: CozyTheme,
    palette: StandbyPalette,
    wallpaper: ImageBitmap?,
    modifier: Modifier = Modifier
) {
    Box(modifier.clip(RoundedCornerShape(28.dp))) {
        StandbyBackground(theme, wallpaper, prefs.wallpaperDim, Modifier.matchParentSize())
        ClockSection(prefs.clockConfig(palette), Modifier.matchParentSize().padding(16.dp))
    }
}

@Composable
private fun SettingsList(
    modifier: Modifier,
    prefs: CozyPrefs,
    theme: CozyTheme,
    palette: StandbyPalette,
    wallpaper: ImageBitmap?,
    media: MediaUiState,
    showPreview: Boolean,
    onPickWallpaper: () -> Unit,
    onOpenNotificationAccess: () -> Unit,
    onOpenAppInfo: () -> Unit
) {
    Box(modifier, contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            Modifier.widthIn(max = 680.dp).fillMaxHeight(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (showPreview) {
                stickyHeader {
                    Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background).padding(bottom = 8.dp)) {
                        ClockPreview(prefs, theme, palette, wallpaper, Modifier.fillMaxWidth().height(176.dp))
                    }
                }
            }
            displaySection(prefs, theme, palette, wallpaper, onPickWallpaper)
            mediaSection(prefs, media, onOpenNotificationAccess, onOpenAppInfo)
            generalSection(prefs)
        }
    }
}

// ---------------------------------------------------------------------------------------------------------
// Sections
// ---------------------------------------------------------------------------------------------------------

private fun LazyListScope.displaySection(
    prefs: CozyPrefs,
    theme: CozyTheme,
    palette: StandbyPalette,
    wallpaper: ImageBitmap?,
    onPickWallpaper: () -> Unit
) {
    item { SectionTitle("Display") }

    item {
        SettingsCard("Clock font", "Every option is a different bundled typeface.") {
            FontGrid(prefs.clockFont, prefs.effectiveWeight, onSelect = prefs::updateClockFont)
        }
    }

    item {
        SettingsCard("Clock appearance") {
            LabeledBlock("Style") {
                ChipRow(ClockStyle.entries, prefs.clockStyle, { it.label }, prefs::updateClockStyle)
            }
            LabeledBlock("Weight") {
                val options = ClockWeightLabels.filter { it.first in prefs.clockFont.weights }
                ChipRow(options, options.firstOrNull { it.first == prefs.effectiveWeight }, { it.second }) {
                    prefs.updateClockWeight(it.first)
                }
            }
            LabeledBlock("Spacing") {
                ChipRow(ClockSpacing.entries, prefs.clockSpacing, { it.label }, prefs::updateClockSpacing)
            }
            LabeledBlock("Colour") {
                ColorSwatches(prefs.clockColor, palette, prefs::updateClockColor)
            }
        }
    }

    item {
        SettingsCard("Time") {
            LabeledBlock("Format") {
                ChipRow(listOf(false, true), prefs.use24h, { if (it) "24-hour" else "12-hour" }, prefs::updateUse24h)
            }
            ToggleRow(
                Icons.Rounded.Timer, "Show seconds",
                "Adds seconds beside the time, or a second hand on the analog clock.",
                prefs.showSeconds, onChange = prefs::updateShowSeconds
            )
        }
    }

    item {
        SettingsCard("Background") {
            if (wallpaper != null) {
                Image(
                    bitmap = wallpaper,
                    contentDescription = "Current background photo",
                    modifier = CardPadding.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(18.dp)),
                    contentScale = ContentScale.Crop
                )
            }
            Row(CardPadding.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = onPickWallpaper, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Wallpaper, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (wallpaper == null) "Choose photo" else "Change photo")
                }
                if (prefs.wallpaperUri != null) {
                    OutlinedButton(onClick = { prefs.updateWallpaper(null) }) { Text("Remove") }
                }
            }
            LabeledBlock("Dimming ${(prefs.wallpaperDim / 0.7f * 100).roundToInt()}%") {
                Slider(
                    value = prefs.wallpaperDim,
                    onValueChange = prefs::updateWallpaperDim,
                    valueRange = 0f..0.7f,
                    enabled = wallpaper != null
                )
            }
            ToggleRow(
                Icons.Rounded.AutoAwesome, "Match colours to photo",
                if (wallpaper == null) "Choose a photo to use this." else "Takes the accent colour from your background.",
                prefs.autoColors, enabled = wallpaper != null, onChange = prefs::updateAutoColors
            )
        }
    }

    item {
        SettingsCard("Theme", "Colours for the built-in background and this screen.") {
            ThemeSwatches(prefs.themeIndex, prefs::updateTheme)
        }
    }
}

private fun LazyListScope.mediaSection(
    prefs: CozyPrefs,
    media: MediaUiState,
    onOpenNotificationAccess: () -> Unit,
    onOpenAppInfo: () -> Unit
) {
    item { SectionTitle("Media") }

    item {
        SettingsCard("Notification access") {
            Row(CardPadding.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (media.accessGranted) Icons.Rounded.Notifications else Icons.Rounded.NotificationsOff,
                    contentDescription = null,
                    tint = if (media.accessGranted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (media.accessGranted) "Access is on" else "Access is off",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        "Android only shows other apps' playback to apps with notification access. " +
                            "CozyStand reads the track and controls playback; it does not read your notifications.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Row(CardPadding.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (media.accessGranted) {
                    OutlinedButton(onClick = onOpenNotificationAccess) { Text("Manage in Android settings") }
                } else {
                    Button(onClick = onOpenNotificationAccess) { Text("Open notification access") }
                }
            }
            if (!media.accessGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                Column(CardPadding.fillMaxWidth()) {
                    Text(
                        "If the switch is greyed out, open App info, tap the three-dot menu and choose " +
                            "Allow restricted settings. Android does this for apps installed outside the Play Store.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = onOpenAppInfo) { Text("Open app info") }
                }
            }
        }
    }

    item {
        SettingsCard("Now playing") {
            val title: String
            val subtitle: String
            when {
                media.hasSession -> {
                    title = media.appLabel ?: "Media app"
                    val state = if (media.isPlaying) "Playing" else "Paused"
                    subtitle = if (media.title != null) "$state: ${media.title}" else state
                }
                media.accessGranted -> {
                    title = "No active player"
                    subtitle = "Start playback in YouTube, YouTube Music, Spotify, VLC or another media app."
                }
                else -> {
                    title = "Player unavailable"
                    subtitle = "Turn on notification access to detect what is playing."
                }
            }
            InfoRow(Icons.Rounded.MusicNote, title, subtitle)
        }
    }

    item {
        SettingsCard("Media card") {
            LabeledBlock("Visibility") {
                ChipRow(MediaCardMode.entries, prefs.mediaMode, { it.label }, prefs::updateMediaMode)
            }
            ToggleRow(
                Icons.Rounded.ColorLens, "Match artwork colours",
                "Tints the play button and progress bar from the album art.",
                prefs.artworkTint, onChange = prefs::updateArtworkTint
            )
        }
    }
}

private fun LazyListScope.generalSection(prefs: CozyPrefs) {
    item { SectionTitle("General") }

    item {
        SettingsCard("Screen") {
            ToggleRow(
                Icons.Rounded.Brightness6, "Keep display awake",
                "Stops the screen from turning off while CozyStand is open.",
                prefs.keepAwake, onChange = prefs::updateKeepAwake
            )
            ToggleRow(
                Icons.Rounded.Fullscreen, "Hide system bars",
                "Full-screen display. Swipe from the edge to reveal them briefly.",
                prefs.immersive, onChange = prefs::updateImmersive
            )
            LabeledBlock("Orientation") {
                ChipRow(OrientationMode.entries, prefs.orientation, { it.label }, prefs::updateOrientation)
            }
        }
    }

    item {
        val context = LocalContext.current
        val version = remember { appVersion(context) }
        SettingsCard("About") {
            InfoRow(Icons.Rounded.ScreenRotation, "CozyStand", if (version.isEmpty()) "Bedside clock and media display" else "Version $version")
        }
    }
}

@Suppress("DEPRECATION")
private fun appVersion(context: Context): String =
    runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull().orEmpty()

// ---------------------------------------------------------------------------------------------------------
// Building blocks
// ---------------------------------------------------------------------------------------------------------

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 8.dp, top = 12.dp)
    )
}

@Composable
private fun SettingsCard(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(CardPadding.fillMaxWidth()) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (subtitle != null) {
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            content()
        }
    }
}

@Composable
private fun LabeledBlock(label: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = CardPadding
        )
        Box(CardPadding.fillMaxWidth()) { content() }
    }
}

/** Horizontally scrollable single-choice chips; never wraps or clips on narrow screens. */
@Composable
private fun <T> ChipRow(options: List<T>, selected: T?, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { option ->
            FilterChip(
                selected = option == selected,
                onClick = { onSelect(option) },
                label = { Text(label(option)) }
            )
        }
    }
}

@Composable
private fun ToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    onChange: (Boolean) -> Unit
) {
    val alpha = if (enabled) 1f else 0.5f
    Row(
        Modifier
            .fillMaxWidth()
            .toggleable(value = checked, enabled = enabled, role = Role.Switch, onValueChange = onChange)
            .padding(horizontal = 20.dp, vertical = 4.dp)
            .heightIn(min = 56.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alpha))
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = alpha))
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alpha))
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = null, enabled = enabled)
    }
}

@Composable
private fun InfoRow(icon: ImageVector, title: String, subtitle: String) {
    Row(CardPadding.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Each tile renders "10:28" in its own typeface at the current weight, so the choice is what you see. */
@Composable
private fun FontGrid(selected: ClockFont, weight: Int, onSelect: (ClockFont) -> Unit) {
    BoxWithConstraints(CardPadding.fillMaxWidth()) {
        val columns = if (maxWidth < 420.dp) 2 else 3
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ClockFont.entries.chunked(columns).forEach { rowFonts ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowFonts.forEach { font ->
                        FontTile(font, font == selected, weight, Modifier.weight(1f)) { onSelect(font) }
                    }
                    repeat(columns - rowFonts.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun FontTile(font: ClockFont, selected: Boolean, weight: Int, modifier: Modifier, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .heightIn(min = 96.dp)
            .clip(shape)
            .background(if (selected) scheme.primaryContainer else scheme.surfaceContainerHigh)
            .border(if (selected) 2.dp else 1.dp, if (selected) scheme.primary else scheme.outlineVariant, shape)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "10:28",
            fontFamily = font.family,
            fontWeight = FontWeight(font.nearestWeight(weight)),
            fontSize = 30.sp,
            color = scheme.onSurface,
            maxLines = 1,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(6.dp))
        Text(font.label, style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun ColorSwatches(selected: ClockColorOption, palette: StandbyPalette, onSelect: (ClockColorOption) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        ClockColorOption.entries.forEach { option ->
            val shown = when (option) {
                ClockColorOption.AUTO -> palette.foreground
                ClockColorOption.ACCENT -> palette.accent
                else -> option.color ?: palette.foreground
            }
            val isSelected = option == selected
            Column(
                Modifier.selectable(selected = isSelected, role = Role.RadioButton, onClick = { onSelect(option) }),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(shown)
                        .border(if (isSelected) 3.dp else 1.dp, if (isSelected) scheme.primary else scheme.outline, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(
                            Icons.Rounded.Check,
                            contentDescription = null,
                            tint = if (shown.luminanceCompat() > 0.5f) Color.Black else Color.White
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(option.label, style = MaterialTheme.typography.labelSmall, color = scheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun ThemeSwatches(selectedIndex: Int, onSelect: (Int) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        CozyThemes.forEachIndexed { index, theme ->
            val isSelected = index == selectedIndex
            Column(
                Modifier.selectable(selected = isSelected, role = Role.RadioButton, onClick = { onSelect(index) }),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Brush.verticalGradient(theme.sky))
                        .border(if (isSelected) 3.dp else 1.dp, if (isSelected) scheme.primary else scheme.outline, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) Icon(Icons.Rounded.Check, contentDescription = null, tint = theme.text)
                }
                Spacer(Modifier.height(4.dp))
                Text(theme.name, style = MaterialTheme.typography.labelSmall, color = scheme.onSurfaceVariant)
            }
        }
    }
}
