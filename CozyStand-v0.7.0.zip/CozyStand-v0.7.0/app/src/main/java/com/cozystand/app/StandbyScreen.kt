package com.cozystand.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.dp

/** Resolves the saved clock choices plus the current palette into one drawable configuration. */
internal fun CozyPrefs.clockConfig(palette: StandbyPalette): ClockConfig {
    val color: Color = when (clockColor) {
        ClockColorOption.AUTO -> palette.foreground
        ClockColorOption.ACCENT -> palette.accent
        else -> clockColor.color ?: palette.foreground
    }
    return ClockConfig(
        font = clockFont,
        weight = effectiveWeight,
        style = clockStyle,
        spacing = clockSpacing,
        use24h = use24h,
        showSeconds = showSeconds,
        color = color,
        accent = palette.accent,
        cardTint = palette.flipCard
    )
}

/**
 * The one and only main screen: date, a very large clock and the media card, with a small settings gear.
 * No header, no dock, no navigation bar, no separate player page.
 */
@Composable
internal fun StandbyScreen(
    prefs: CozyPrefs,
    theme: CozyTheme,
    palette: StandbyPalette,
    wallpaper: ImageBitmap?,
    media: MediaUiState,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onOpenAccessSettings: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val config = prefs.clockConfig(palette)
    val showCard = when (prefs.mediaMode) {
        MediaCardMode.ALWAYS -> true
        // Still show the card when access is missing, otherwise there is no hint how to enable it.
        MediaCardMode.WHEN_ACTIVE -> media.hasSession || !media.accessGranted
    }

    Box(modifier.fillMaxSize()) {
        StandbyBackground(theme, wallpaper, prefs.wallpaperDim, Modifier.fillMaxSize())

        BoxWithConstraints(Modifier.fillMaxSize().safeDrawingPadding()) {
            // Plain values captured from this scope; nothing below relies on implicit receivers.
            val screenWidth = maxWidth
            val screenHeight = maxHeight
            val dense = screenHeight < 480.dp
            val horizontalPadding = (screenWidth * 0.03f).coerceIn(20.dp, 40.dp)

            Column(
                Modifier
                    .fillMaxSize()
                    .padding(
                        start = horizontalPadding,
                        end = horizontalPadding,
                        top = if (dense) 16.dp else 32.dp,
                        bottom = if (dense) 12.dp else 28.dp
                    ),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ClockSection(config, Modifier.weight(1f).fillMaxWidth())
                AnimatedVisibility(
                    visible = showCard,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(Modifier.height(if (dense) 8.dp else 20.dp))
                        MediaCard(
                            media = media,
                            palette = palette,
                            artworkTint = prefs.artworkTint,
                            dense = dense,
                            onPrevious = onPrevious,
                            onPlayPause = onPlayPause,
                            onNext = onNext,
                            onOpenAccessSettings = onOpenAccessSettings,
                            modifier = Modifier.widthIn(max = 880.dp).fillMaxWidth()
                        )
                    }
                }
            }

            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 4.dp, end = 4.dp).size(48.dp)
            ) {
                Icon(
                    Icons.Rounded.Settings,
                    contentDescription = "Settings",
                    tint = palette.foreground.copy(alpha = 0.78f),
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}
