package com.cozystand.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.ColorUtils
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

internal class WallpaperResult(val image: ImageBitmap, val accent: Color?)

/**
 * Decodes the chosen photo on a background thread, scaled so its longest edge is at most [maxEdge]
 * pixels (a 50 MP photo would otherwise exhaust memory), and samples an accent colour from it.
 * Returns null if the image cannot be read.
 */
internal suspend fun loadWallpaper(context: Context, uri: Uri, maxEdge: Int = 3200): WallpaperResult? =
    withContext(Dispatchers.IO) {
        runCatching {
            val bitmap = decodeScaled(context, uri, maxEdge)
            WallpaperResult(bitmap.asImageBitmap(), extractAccent(bitmap))
        }.getOrNull()
    }

private fun decodeScaled(context: Context, uri: Uri, maxEdge: Int): Bitmap {
    val resolver = context.contentResolver
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        val source = ImageDecoder.createSource(resolver, uri)
        return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            // Software allocator: hardware bitmaps cannot be read by Palette.
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val longest = max(info.size.width, info.size.height)
            if (longest > maxEdge) {
                val scale = maxEdge.toFloat() / longest
                decoder.setTargetSize(
                    (info.size.width * scale).roundToInt().coerceAtLeast(1),
                    (info.size.height * scale).roundToInt().coerceAtLeast(1)
                )
            }
        }
    }
    // API 26–27 have no ImageDecoder.
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / sample > maxEdge) sample *= 2
    val options = BitmapFactory.Options().apply { inSampleSize = sample }
    return resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
        ?: error("Could not decode $uri")
}

/** Picks a lively swatch from [bitmap] and lightens it until it reads clearly on a dark scrim. */
internal fun extractAccent(bitmap: Bitmap): Color? {
    if (bitmap.config == Bitmap.Config.HARDWARE) return null
    val palette = Palette.from(bitmap).maximumColorCount(16).generate()
    val swatch = palette.lightVibrantSwatch
        ?: palette.vibrantSwatch
        ?: palette.lightMutedSwatch
        ?: palette.dominantSwatch
        ?: return null
    return Color(swatch.rgb).ensureLight()
}

/** Blends towards white until the colour has at least [minLuminance] relative luminance. */
internal fun Color.ensureLight(minLuminance: Double = 0.55): Color {
    var argb = this.toArgb()
    var steps = 0
    while (ColorUtils.calculateLuminance(argb) < minLuminance && steps < 12) {
        argb = ColorUtils.blendARGB(argb, android.graphics.Color.WHITE, 0.12f)
        steps++
    }
    return Color(argb)
}
